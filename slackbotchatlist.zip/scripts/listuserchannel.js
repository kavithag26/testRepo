var Slack = require('slack-node');
//apiToken ="xoxp-116437723937-178053086277-181843649987-09d93233cf9f0eb695a6e94f0524fbdb" ;
	//apiToken=config.Slack_Token_4Team;
	//slack = new Slack(apiToken);
function list() { };

var usrlist;
list.channellist=function(slacktoken,callback){
	apiToken =slacktoken;                  //"xoxp-116437723937-178053086277-181843649987-09d93233cf9f0eb695a6e94f0524fbdb" ;
	slack = new Slack(apiToken);
		var res="";
		//jsonobj['channels']=[];
	slack.api("channels.list", function(err, response) {
		  
		if(!response.error)  {
		var channellist=response.channels;
		
		
		
		for(var attributename in channellist){
			
			var key=channellist[attributename].id;
			var value=channellist[attributename].name;
			
			res+="id : "+channellist[attributename].id+",name: "+channellist[attributename].name+"\n";
		    
		}
		
		var chnlist=res
		//console.log(chnlist);
		callback(null,chnlist,null);
		}if(response.error){
		//console.log(response.error);
		callback(null,null,response.error);
		}
		if(err){
			//console.log(err);
			callback(err,null,null);
		}
		});
	

}

list.userlist=function(slacktoken,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
var res="";
		//jsonobj['users']=[];
	slack.api("users.list", function(err, response ,stderr) {
		  
		if(!response.error)  {
		var userslist=response.members;
	
		
		for(var attributename in userslist){
			
		    
			var key=userslist[attributename].id;
			var value=userslist[attributename].name;
			
			
			res+="id : "+channellist[attributename].id+",name: "+channellist[attributename].name+"\n";
		    
		}
		//console.log(jsonobj);
		var usrlist=res;
		callback(null,usrlist,null);
		}if(response.error){
		callback(null,null,response.error);
		}
		if(err){
			callback(err,null,null);
		}
		});
}
module.exports=list;