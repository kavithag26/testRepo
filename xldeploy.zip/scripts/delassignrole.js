var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var delassignrole= function (url, username, password, role, user, callback) {
	
var xldeploy_url = url+'/deployit/security/role/'+role+'/'+user;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'DELETE',
  url: xldeploy_url,
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  if(response.statusCode==204){
	  var list='';
	  
	 
		list=role+ " role "+role+"removed for "+user +" successfully";

	 
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  delassignrole: delassignrole	// MAIN FUNCTION
  
}
//delassignrole("http://10.224.86.160:4516","admin","Devops@123","test")