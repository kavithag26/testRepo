var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var deleterole= function (url, username, password, role, callback) {
	
var xldeploy_url = url+'/deployit/security/user/'+role;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'DELETE',
  url: xldeploy_url,
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  if(response.statusCode==204){
	  var list='';
	  
	 
		list=role+ " role deleted successfully";

	 
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  deleterole: deleterole	// MAIN FUNCTION
  
}

//deleterole("http://10.224.86.160:4516","admin","Devops@123","test")