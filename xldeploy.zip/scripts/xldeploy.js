var request=require('request');
var fs=require('fs');
var deployment= function (url, username, password, filename, callback) {
	
//api for deploying war in tomcat by <configfile>
var file='./'+filename;

fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  
  
  
var xldeploy_url = url+"/deployit/deployment"

var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/xml'},
  body:data};

request(options, function (error, response, body) {
	
	
	console.log(body)
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  
	  
	  var xldeploy_url = url+"/deployit/task/"+body+"/start"
	  console.log(xldeploy_url);
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url};

request(options, function (error, response, body) {
	
	if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  console.log("deployed");
	 callback(null,"deployed your artifact",null); 
  }
	  
});
	  
  }
});
});
}


module.exports = {
  deployment: deployment	// MAIN FUNCTION
  
}
//deployment("http://10.224.86.160:4516","admin","Devops@123","deployment.xml")