var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var deleteuser= function (url, username, password, user, callback) {
	
var xldeploy_url = url+'/deployit/security/user/'+user;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'DELETE',
  url: xldeploy_url,
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  var list='';
  if(response.statusCode==204){
	  
	 
		list+="username: "+user+" deleted";

	 
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  deleteuser: deleteuser	// MAIN FUNCTION
  
}
//deleteuser("http://10.224.86.160:4516","admin","Devops@123","anu")