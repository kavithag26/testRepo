var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var getrepo= function (url, username, password, callback) {
	
var xldeploy_url = url+'/deployit/repository/query';
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'GET',
  url: xldeploy_url,
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  if(response.statusCode==200){
	  var list='';
	  var json = JSON.parse(parser.toJson(body));
	  for(i=0;i<json.list.ci.length;i++){
		if(json.list.ci[i].type!="internal.Root")
		{
			list+=json.list.ci[i].ref+"\n";
			
		}
	  }
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  getrepo: getrepo	// MAIN FUNCTION
  
}
//getrepo("http://10.224.86.160:4516","admin","Devops@123")