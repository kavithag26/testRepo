var request=require('request');
var fs=require('fs');
var undeployment= function (url, username, password, version, deployedApplication, callback) {
	var xldeploy_url = url+"/deployit/deployment/prepare/undeploy/?version="+version+"&deployedApplication="+deployedApplication;
		var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: xldeploy_url,
  };
  
  request(options, function (error, response, body) {
	
	
	console.log(body)
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  var undeploydata=body;
	  var xldeploy_url = url+"/deployit/deployment"

var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/xml'},
  body:undeploydata};

request(options, function (error, response, body) {
	
	
	console.log(body)
	var taskid=body	
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  
	  
	  var xldeploy_url = url+"/deployit/task/"+body+"/start"

var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url};

request(options, function (error, response, body) {
	
	if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  console.log("undeployed");
	 callback(null,"undeployed artifact",null); 
  }
	  
});
  }
});


}
  });
}

module.exports = {
  undeployment: undeployment	// MAIN FUNCTION
  
}
//undeployment("http://10.224.86.160:4516","admin","Devops@123","Applications/retailone/1.0","Environments/bottest/retailone")
