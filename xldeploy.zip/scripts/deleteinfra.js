var request=require('request');
var fs=require('fs');
var deleteinfra= function (url, username, password, id, callback) {
	//api for adding repository

  
	var xldeploy_url = url+"/deployit/repository/ci/"+id
	var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'DELETE',
  url: xldeploy_url
  };

request(options, function (error, response, body) {
	
	
	console.log(body)
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  else{
	  console.log(id+" deleted successfully");
	  callback(null,null,id+" deleted successfully");
  }
});

};
module.exports = {
  deleteinfra: deleteinfra	// MAIN FUNCTION
  
}
//("http://10.224.86.160:4516","admin","Devops@123","Infrastructure/my-new-ci")