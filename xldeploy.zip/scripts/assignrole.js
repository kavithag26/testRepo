var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var assignrole= function (url, username, password, role, user, callback) {
	
var xldeploy_url = url+'/deployit/security/role/'+role+"/"+user;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'PUT',
  url: xldeploy_url,
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  if(response.statusCode==204){
	  var list='';
	  
	 
		list=role+ " role assigned to "+user+" successfully";

	 
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  assignrole: assignrole	// MAIN FUNCTION
  
}
//assignrole("http://10.224.86.160:4516","admin","Devops@123","test")