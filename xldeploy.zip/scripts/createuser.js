var request = require("request");
var fs=require('fs');
var parser = require('xml2json');

var createuser= function (url, username, password, user, pswd, callback) {
var data='<user admin="false"><username>'+user+'</username><password>'+pswd+'</password></user>'
var xldeploy_url = url+'/deployit/security/user/'+user;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'POST',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/xml'},
   body:data
   };

request(options, function (error, response, body) {
  if (error) {console.log(error); callback(error,null,null);}
  if(response.statusCode==200){
	  var list='';
	  var json = JSON.parse(parser.toJson(body));
	 
		list+="created user: "+json.user.username;

	 
	  console.log(list);
	  callback(null,list,null)
	  }

   if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
});

}
module.exports = {
  createuser: createuser	// MAIN FUNCTION
  
}
//createuser("http://10.224.86.160:4516","admin","Devops@123",'anu','anu')