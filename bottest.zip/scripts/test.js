var request = require("request");

//Function to change the status of issue with parameters url,username,password,issue_key,status
var test_call = function (nexus_url, nexus_user_id, nexus_password, repo, callback){

//url=nexus_url+'/nexus/service/local/lucene/search?g='+repo+''
url='http://54.209.104.148:8081/nexus/service/local/lucene/search'
//url="http://54.209.104.148:8081/nexus/service/local/lucene/search?g=com.cognizant.devops"
console.log(url)
var options = {
		auth: {
		'user': nexus_user_id,
		'pass': nexus_password
		},
		method: 'GET',
		url: url,
		qs: {
   		 'g': 'com.cognizant.devops',
		 'a': 'PlatformService',
		 'v': '1.0-SNAPSHOT',
		 'p':'war'
		}
		}
request(options, function (error, response, body) {
	if(error){
		callback(error,null,null)
console.log(error)
	}
	if(response.statusCode==200){
console.log(body)
result = body.split('<artifact>')
			if(result.length==1){
				dt = 'No artifacts found for groupId: '+repo
				console.log(dt);
				}
			else{

				
				console.log(result[1].split('<groupId>')[1].split('</groupId>')[0])
				console.log(result[1].split('<artifactId>')[1].split('</artifactId>')[0])
				console.log(result[1].split('<version>')[1].split('</version>')[0])
				dt = '*No.*\t\t\t*Group Id*\t\t\t*Artifact Id*\t\t\t*Version*\t\t\t*Repo Id*\n'
				
				for (var i=1;i<result.length;i++){
					if(result[i].split('<artifactId>')[1].split('</artifactId>')[0]=='PlatformInsights' || result[i].split('<artifactId>')[1].split('</artifactId>')[0]=='PlatformUI2.0' ||result[i].split('<artifactId>')[1].split('</artifactId>')[0]=='PlatformService' ){
						dt = dt + i+'\t\t\t'+result[i].split('<groupId>')[1].split('</groupId>')[0]+'\t\t\t'+result[i].split('<artifactId>')[1].split('</artifactId>')[0]+'\t\t\t'+result[i].split('<version>')[1].split('</version>')[0]+'\n'
					}
					
//+'\t\t\t'+result[i].split('<latestReleaseRepositoryId>')[1].split('</latestReleaseRepositoryId>')[0]+'\n'
				}
				console.log(dt);
				callback(null,dt,null)
			}
	}
	else{
		callback(null,null,"error in getting artifacts")
console.log(body)
	}
});
		
				
					
}
module.exports = {
  test_call: test_call	// MAIN FUNCTION
  
}
//test_call("http://54.209.104.148:8081","admin","admin123","com.cognizant.devops");