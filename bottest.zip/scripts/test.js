var request = require("request");

//Function to change the status of issue with parameters url,username,password,issue_key,status
var test_call = function (nexus_url, nexus_user_id, nexus_password, repo, callback){

url=nexus_url+'/nexus/service/local/lucene/search?g='+repo+''
//url="http://54.209.104.148:8081/nexus/service/local/lucene/search?g=com.cognizant.devops"
console.log(url)
var options = {
		auth: {
		'user': nexus_user_id,
		'pass': nexus_password
		},
		method: 'GET',
		url: url
		}
request(options, function (error, response, body) {
	if(error){
		callback(error,null,null)
	}
	if(response.statusCode==200){
result = body.split('<artifact>')
			if(result.length==1){
				dt = 'No artifacts found for groupId: '+repo
				console.log(dt);
				}
			else{

				
				console.log(result[1].split('<groupId>')[1].split('</groupId>')[0])
				console.log(result[1].split('<artifactId>')[1].split('</artifactId>')[0])
				console.log(result[1].split('<version>')[1].split('</version>')[0])
				dt = '*No.*\t\t\t*Group Id*\t\t\t*Artifact Id*\t\t\t*Version*\t\t\t*Repo Id*\n'
				
				for (var i=1;i<result.length;i++){
					dt = dt + i+'\t\t\t'+result[i].split('<groupId>')[1].split('</groupId>')[0]+'\t\t\t'+result[i].split('<artifactId>')[1].split('</artifactId>')[0]+'\t\t\t'+result[i].split('<version>')[1].split('</version>')[0]
//+'\t\t\t'+result[i].split('<latestReleaseRepositoryId>')[1].split('</latestReleaseRepositoryId>')[0]+'\n'
				}
				console.log(dt);
				callback(null,dt,null)
			}
	}
	else{
		callback(null,null,"error in getting artifacts")
	}
});
		
				
					
}
module.exports = {
  test_call: test_call	// MAIN FUNCTION
  
}
//test_call("http://54.209.104.148:8081","admin","admin123","com.cognizant.devops");