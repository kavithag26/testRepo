
module.exports = (robot) => {
  console.log("heloo");
  return robot.router.get('/status', function(req, res) { 
  var room=req.params.room;
  robot.messageRoom(room,'hii');
  console.log("hi");
  console.log(req);
  res.end("hi");
  });
};