module.exports = (robot) => {
 const patt = new RegExp("^@?" + robot.name + " +.*$", "i");
 robot.catchAll(patt, (msg) => {
  message = msg.message;
  message.text = message.text || '';
  
   if(patt.test(message.text))
   {
    msg.send("Sorry I did not get you");
   }
 });
};