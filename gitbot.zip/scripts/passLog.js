const fs = require('fs');
const logger = require('../node_modules/hubot-elasticsearch-logger/lib/logger');

module.exports = (robot) => {
var passHuLogs = function () {
	
    const config = './hubot.log';
    var dt = fs.readFileSync(config, 'utf8');
    const log = {
      user: "Bot",
      type: "DeployData",
      message: dt,//log data goes here
      timestamp: new Date()
	};
    logger.logs(log, (err) => {
      if (err) return robot.logger.error(err.message);
    });
};

setTimeout(passHuLogs,1500);
};