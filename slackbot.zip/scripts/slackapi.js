var Slack = require('slack-node');
//apiToken ="xoxp-116437723937-178053086277-181843649987-09d93233cf9f0eb695a6e94f0524fbdb" ;
	//apiToken=config.Slack_Token_4Team;
	//slack = new Slack(apiToken);
//list = require('./listuserchannel.js');
function slackapi() { };

var usrlist;
var channellist=function(slacktoken,callback){
	apiToken =slacktoken;                  //"xoxp-116437723937-178053086277-181843649987-09d93233cf9f0eb695a6e94f0524fbdb" ;
	slack = new Slack(apiToken);
		var jsonobj={};
		jsonobj['channels']=[];
	slack.api("channels.list", function(err, response) {
		  
		if(!response.error)  {
		var channellist=response.channels;
		
		
		
		for(var attributename in channellist){
			
			var key=channellist[attributename].id;
			var value=channellist[attributename].name;
			
			jsonobj['channels'].push({id : channellist[attributename].id,name:channellist[attributename].name});
		    
		}
		
		var chnlist=jsonobj.channels
		//console.log(chnlist);
		callback(null,chnlist,null);
		}if(response.error){
		//console.log(response.error);
		callback(null,null,response.error);
		}
		if(err){
			//console.log(err);
			callback(err,null,null);
		}
		});
	

}



var userlist=function(slacktoken,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
var jsonobj={};
		jsonobj['users']=[];
	slack.api("users.list", function(err, response ,stderr) {
		  
		if(!response.error)  {
		var userslist=response.members;
	
		
		for(var attributename in userslist){
			
		    
			var key=userslist[attributename].id;
			var value=userslist[attributename].name;
			
			
			jsonobj['users'].push({id : userslist[attributename].id,name:userslist[attributename].name});
		    
		}
		//console.log(jsonobj);
		var usrlist=jsonobj.users;
		callback(null,usrlist,null);
		}if(response.error){
		callback(null,null,response.error);
		}
		if(err){
			callback(err,null,null);
		}
		});
}



slackapi.channelhistory=function(slacktoken,channelname,count,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
function formatDate(date){
				
				var dd = date.getDate();
				var mm = date.getMonth()+1;
				//console.log(day +" "+ months);
				var yyyy = date.getFullYear();
				if(dd<10) {dd='0'+dd}
				if(mm<10) {mm='0'+mm}
				
				var HH=date.getHours();
				var MM=date.getMinutes();
				var ss=date.getSeconds();
				if(HH<10) {HH='0'+HH}
				if(MM<10) {MM='0'+MM}
				if(ss<10) {ss='0'+ss}

				date = dd+'/'+mm+'/'+yyyy+" "+HH+':'+MM+":"+ss;
				//date= day+" "+months+" "+dd+" "+yyyy
				return date
			}

var convcnt=count
channellist(slacktoken,function(err,response,stderr){
if(response){
var chnlist=response;
//console.log(response);
//console.log(err);
for(var chname in chnlist){
			//console.log(chnlist[chname].name);
			if(chnlist[chname].name==channelname)
				{
				
				channelid=chnlist[chname].id;
				//console.log(channelid);
				break;
				}
			
		}

var convtxt="";
if(channelid){
slack.api("channels.history", {channel:channelid,count:convcnt}, function(err, response) {
	if(!response.error){
var history=response.messages;
userlist(slacktoken,function(err,response,stderr){
	if(response){
	var usrlist=response;
	for(var conv in history){
		for(var usrname in usrlist){
			if(history[conv].user==usrlist[usrname].id){
				var date = new Date(history[conv].ts*1000);
				var dformat =formatDate(date);
				convtxt+=usrlist[usrname].name+" "+dformat+" "+history[conv].text+"\n";
				break;
			}
		}
	
	}
//console.log("js::"+convtxt);
callback(null,convtxt,null);
}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});

}
if(response.error){
	//console.log(response.error);
	callback(null,null,response.error);
}
if(err){
			//console.log("error in getting channel conversation");
			callback(err,null,null);
		}
});
}
}
//if(err){callback(err,null,null);}
//if(stderr){callback(null,null,stderr);}
});
}

slackapi.createchannel=function(slacktoken,channelname,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
var reply;
slack.api("channels.create", {name:channelname},function(err, response) {
		  //console.log(response);
		  if(response.error){
			  //console.log(response.error);
			  callback(null,null,response.error);
		  }
		  if(!response.error){
			  
			  reply=response.channel.name+" is created successfully and its id is: "+response.channel.id;
			  //console.log(reply);
			  callback(null,reply,null);
		  }
		  if(err){
			//console.log("error in creating channel");
			callback(err,null,null);
		}

		});

}

slackapi.removeuser=function(slacktoken,channelname,username,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
channellist(slacktoken,function(err,response,stderr){
if(response){
var chnlist=response;
for(var chname in chnlist){
			//console.log(channellist[chname].id);
			if(chnlist[chname].name==channelname)
				{
				
				channelid=chnlist[chname].id;
				//console.log(channelid);
				break;
				}
			
		}
userlist(slacktoken,function(err,response,stderr){
	if(response){
	var usrlist=response;
	
	for(var usrname in usrlist){
			if(username==usrlist[usrname].name){
				userid=usrlist[usrname].id
				break;
			}
		}
	slack.api("channels.kick", {channel:channelid,user:userid}, function(err, response) {
		if(response.error){
			  //console.log(response.error);
			  callback(null,null,response.error);
		  }
		  if(!response.error){
			  
			  reply=username+" removed from "+channelname+" successfully.";
			  //console.log(reply);
			   callback(null,reply,null);
		  }
		  if(err){
			//console.log("error in removing user from channel");
			callback(err,null,null);
		}

		});
	}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});
	}	
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});
	
	
	

}

slackapi.adduser=function(slacktoken,channelname,username,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
	channellist(slacktoken,function(err,response,stderr){
	if(response){
var chnlist=response;
for(var chname in chnlist){
			//console.log(channellist[chname].id);
			if(chnlist[chname].name==channelname)
				{
				
				channelid=chnlist[chname].id;
				//console.log(channelid);
				break;
				}
			
		}
userlist(slacktoken,function(err,response,stderr){
	if(response){
	var usrlist=response;
	
	for(var usrname in usrlist){
			if(username==usrlist[usrname].name){
				userid=usrlist[usrname].id
				break;
			}
		}
	slack.api("channels.invite", {channel:channelid,user:userid}, function(err, response) {
		if(response.error){
			  //console.log(response.error);
			  callback(null,null,response.error);
		  }
		  if(!response.error){
			  
			   reply=username+" add to "+channelname+" successfully.";

			  //console.log(reply);
			  callback(null,reply,null);
		  }
		  if(err){
			//console.log("error in adding user to channel");
			callback(err,null,null);

		}

		});
}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});
	}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}	
	});
}

slackapi.channelarchive=function(slacktoken,channelname,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
	channellist(slacktoken,function(err,response,stderr){
	if(response){
var chnlist=response;
for(var chname in chnlist){
			//console.log(channellist[chname].id);
			if(chnlist[chname].name==channelname)
				{
				
				channelid=chnlist[chname].id;
				//console.log(channelid);
				break;
				}
			
		}

var convtxt="";
slack.api("channels.archive", {channel:channelid}, function(err, response) {
	if(!response.error){
	var rply=channelname+" is archived successfully."
	//console.log(rply);
	callback(null,rply,null);
}
if(response.error){
	 //console.log(response.error);
	 callback(null,null,response.error);
}
if(err){
			//console.log("error in getting channel conversation");
			callback(err,null,null);
		}
});
	}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});
}

slackapi.inviteuser=function(slacktoken,emailid,channelname,callback){
	apiToken =slacktoken;
	slack = new Slack(apiToken);
	channellist(slacktoken,function(err,response,stderr){
	if(response){
var chnlist=response;
for(var chname in chnlist){
			//console.log(channellist[chname].id);
			if(chnlist[chname].name==channelname)
				{
				
				channelid=chnlist[chname].id;
				//console.log(channelid);
				break;
				}
			
		}
slack.api("users.admin.invite", {email:emailid,channels:channelid}, function(err, response) {
	if(!response.error){
	var rply="Invite is send to "+emailid
	//console.log(rply);
	callback(null,rply,null);
}
if(response.error){
	//console.log(response.error);
	 callback(null,null,response.error);
}
if(err){
			//console.log("error in getting channel conversation");
			callback(err,null,null);
		}
});
	}
if(err){callback(err,null,null);}
if(stderr){callback(null,null,stderr);}
});
}

//createchannel("mychanneltest");
//channelhistory("random",10);
//removeuser("random","sowmiya");
//adduser("random","sowmiya");
//channelarchive("mychanneltest");
module.exports = slackapi;

