var nodemailer = require('nodemailer');

var function_call = function (callback_sendmail) {
	console.log('aaaaaaaaaaaaaaaaa');
var transporter = nodemailer.createTransport('smtps://nandhu.anu.k%40gmail.com:internet22@smtp.gmail.com');


var mailOptions = {
    from: 'nandhu.anu.k@gmail.com', 
    to: 'nandhu.anu.k@gmail.com',
    subject: 'sample', 
    text: 'sample', 
    html: '' 
};


transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
	
});


}
module.exports = {
 sendmail: function_call	// MAIN FUNCTION
}