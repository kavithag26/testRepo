var request = require("request");
var status_call = function (jira_repourl, username, password, issue_key, callback_jira_status){
var jira_repourl = jira_repourl+"/rest/api/latest/issue/"+issue_key;
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'GET',
  url: jira_repourl,
  qs: { 'expand': 'transitions' },
  json: true 
  };

request(options, function (error, response, body) {
	/* console.log (response.body); */
  if (error)
  {
	  callback_jira_status("Something went wrong","Something went wrong",null);
  }
  else if(response.body)
  {
	  if(response.body.errorMessages){
	  callback_jira_status("You might not have permission or Jira Ticket Didn't Exist.","You might not have permission or Jira Ticket Didn't Exist.",response.body.errorMessages);}
	  else
	  callback_jira_status(null,response,null);
  } 
  else
  {
	  callback_jira_status(null,response,null);
  }

  
});

}

module.exports = {
  status_issue: status_call	// MAIN FUNCTION
  
}