//Load dependency
var request = require("request");

//Function to change the status of issue with parameters url,username,password,issue_key,status
var transition_call = function (jira_repourl, username, password, issue_key, issue_status, callback_jira_transition){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+issue_key+"/transitions";
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'POST',
  url: jira_repourl,
  qs: { expand: 'transitions.fields' },
  headers: 
   { 
   'Content-Type': 'application/json'
   },
  body: { 
            transition: {
                            id: issue_status 
                        }
        },
  json: true 
  };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_jira_transition("Something Went Wrong","Something Went Wrong",null);
  }
   else if(response.body)
  {
	  if(response.body.errorMessages){
	  callback_jira_transition("You might not have permission or Jira Ticket Didn't Exist.","You might not have permission or Jira Ticket Didn't Exist.",response.body.errorMessages);}
  } 
  else
  {	
	  callback_jira_transition(null,"Status Changed Successfully",body);
  } 
});
}
module.exports = {
  transition_issue: transition_call	// MAIN FUNCTION  
}