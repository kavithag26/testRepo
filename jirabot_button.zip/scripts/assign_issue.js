var request = require("request");
var assign_call = function (jira_repourl, username, password, jira_ticket, assignee_name, callback_jira_assign){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+jira_ticket;
var errormsg, lines;
var options = {
  auth: {
        'user': username,
        'pass': password
    },
  method: 'PUT',
  url: jira_repourl,
  headers: 
   { 
   
   },
  body: {
          fields: {
                    assignee: {
                                name: assignee_name 
                              } 
                  } 
        },
  json: true 
};

request(options, function (error, response, body) {
console.log (response);
  if (error)
  {
	  callback_jira_assign("Something Went Wrong Jira ticket cannot be assigned.","Something Went Wrong Jira ticket cannot be assigned.",null);
  }
    else if(response.body)
  {
	  if(response.body.errors){
	  callback_jira_assign("Either Assignee or Jira Ticket Didn't Exist","Either Assignee or Jira Ticket Didn't Exist",response.body.errors);
	  }
  } 
  else
  {
	 callback_jira_assign(null,"Successfully Assigned",null);
  }
  
});

}

module.exports = {
  assign_issue: assign_call	// MAIN FUNCTION
  
}