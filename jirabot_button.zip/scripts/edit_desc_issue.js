var request = require("request");

//Function to add description with comment to jira issue with parameters url,username,password,issue_key,description,comment
var edit_call = function (jira_repourl, username, password, issue_key, desc_jira , comment_jira, callback_jira_edit){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+issue_key;
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'PUT',
  url: jira_repourl,
  headers: 
   { 
   'Content-Type': 'application/json'
   },
  body: 
   { 
     update:{ 
              description:[{
                            set: desc_jira 
                          }],
              comment:[{ 
                           add:{ 
                                body: comment_jira 
                               }
                      }]
            }
    },
  json: true 
  };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_jira_edit("Something went wrong","Something went wrong",null);
  }
  else
  {
	  callback_jira_edit(null,"Comment Posted Successfully",null);
  } 
});
}
module.exports = {
  edit_desc_issue: edit_call	// MAIN FUNCTION 
}