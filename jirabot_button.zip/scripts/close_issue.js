var request = require("request");
var close_call = function (jira_repourl, username, password, issue_key, callback_jira_close){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+issue_key+"/transitions";
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'POST',
  url: jira_repourl,
  qs: { expand: 'transitions.fields' },
  headers: 
   { 
   'Content-Type': 'application/json'
   },
  body: { 
            transition: {
                            id: '941' 
                        }
        },
  json: true 
  };

request(options, function (error, response, body) {
	console.log (response.body);
  if (error)
  {
	  callback_jira_close("Jira Ticket Cannot Be Closed. Issue Doesnot Exist","Jira Ticket Cannot Be Closed. Issue Doesnot Exist",null);
  }
   else if(response.body)
  {
	  if(response.body.errorMessages){
	  callback_jira_close("You might not have permission or Jira Ticket Didn't Exist.Also follow the workflow graph to close issue","You might not have permission or Jira Ticket Didn't Exist.Also follow the workflow graph to close issue",response.body.errorMessages);}
  } 
  else
  {	
	  callback_jira_close(null,"Successfully Closed",body);
  }

  
});

}

module.exports = {
  close_issue: close_call	// MAIN FUNCTION
  
}