var request = require("request");
var function_call = function (nexus_url, nexus_user_id, nexus_password, userid, callback_delete_user) {
	//userid = usertocreate && userid(command)
	//roleid = reporole && role(command)
	//nexus_userid(env)
	//url(env)
	//password(env)
	   random_password=(Math.random()*1e39).toString(36);
   random_password = random_password.toLowerCase();
	nexus_repourl = nexus_repourl + "/service/local/users";

	
	
	
	
	var options = {
		    auth: {
        'user': nexus_user_id,
        'pass': nexus_password
    },
	method: 'DELETE',
  url: nexus_repourl,
  headers: 
   {
     'content-type': 'application/json' },
  body: 
   { data: 
      { email: 'testing@example.com',
        userId: userid,
        status: 'active',
        roles: [ roleid ],
        password: random_password } },
  json: true };
	
	
	
	function callback(error, response, body) {
    if (!error) {

	
	if(JSON.stringify(response.statusCode) == '200')
	{
	

	callback_delete_user(null,"Successfully deleted",null);
	}
	else
	{
		

	callback_delete_user(error,response,null);
	}
    }
	else
	{
		callback_delete_user(error,"Some error is there",null);

	}
	
}

request(options, callback);
	
	
	
	
	
	
	
	}




module.exports = {
  delete_user: function_call	// MAIN FUNCTION
  
}