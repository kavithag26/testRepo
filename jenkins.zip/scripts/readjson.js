var fs = require('fs')

function readworkflow(callback) {
	console.log("In reading json");
 //var cmd=method;
 var obj = '';
 console.log(obj);
 if(!obj){
 obj = JSON.parse(fs.readFileSync('./workflow.json', 'utf8'));}
 console.log(obj)
 callback(null, obj,null);
/*for(var i=0;i<obj.workflow.length;i++)
{
	var jsonData = obj.workflow[i].command;
	console.log(jsonData);
	if(jsonData==cmd)
	{
		console.log("Data Matched"+obj.workflow[i])
		callback(null, obj.workflow[i],null);
	}
}*/
}
module.exports = {
  readworkflow_coffee: readworkflow	// MAIN FUNCTION
  
}