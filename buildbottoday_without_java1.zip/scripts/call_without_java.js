//var Git = require("../node_modules/nodegit");
var exec = require('child_process').exec;

var request = require('../node_modules/request');

var fs = require('fs');
var name1 = '';
var repo1 ='';
var branch1 = '';
var pythonservice1 = '';


var check = '';



var result = 'false';

var function_call = function (name, repo, branch, pythonservice, clone_link, callback_for_token_coffee) {

name1 = name;
repo1 = repo;
branch1 = branch;
pythonservice1 = pythonservice;


path_sample = '/tmp';
//Git.Clone(clone_link, path_sample)

//  .catch(function(err) { console.log(err); });

  //wait(5000);
  
  function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}
  
  
  //console.log("Downloaded from GitHub");
  
  


filepath = "/tmp/spring-petclinic/.git/config";
user_name_hold_url = '';
ref_name_hold_url = '';
entire_url_from_config = '';
check = '';
fs.readFile(filepath, function (err, data) {
   if (err){
      console.log(err.stack);
      return;
   }
   data = data.toString();
   //console.log(data.toString());
   split_data = data.split("\n");
   for(i=0;i<split_data.length;i++)
   {
	  //console.log(split_data[i].trim());
		split_data_1 = split_data[i].split("=");
		//console.log(split_data_1[0].trim());
		if(split_data_1[0].trim() == 'url')
		{
			console.log(split_data_1[0].trim()+"------------"+split_data_1[1].trim());
			user_name_hold_url = split_data_1[1].trim();
			entire_url_from_config = user_name_hold_url;
		}
		if(split_data_1[0].trim() == 'merge')
		{
			console.log(split_data_1[0].trim()+"------------"+split_data_1[1].trim());
			ref_name_hold_url = split_data_1[1].trim();
		}
		
   }
   user_name_hold_url = user_name_hold_url.split("/");
   
   console.log("Ref : "+ref_name_hold_url);//ref
   console.log("path with namespcae : "+user_name_hold_url[3].concat("/").concat(repo1));//IT IS ORGANIZATION NAME FROM CONFIG AND REPO
   
   x=(Math.random()*1e62).toString(36);
   console.log("Namespace :: "+name1);
   
   console.log("Email :: "+name1);// NAME COMING FROM ARGUMENTS
   console.log("commit id :: "+x);//commitid
	check = x;
   console.log("name : "+repo1);
   //console.log("Repo : "+repo1);
   
   var jsonobj_new = {

            ref: "a",
            project: 
            {
                path_with_namespace: "a",
                namespace: "a",
                http_url: "a"
            },
			commits: [{
			         author:
					 {
						 email: "a"
					 },
					 id: "a"
			}],
	    repository:
	    {
		name: "a",
		git_http_url: "BOT"
	    }
        

};
jsonobj_new.ref = ref_name_hold_url;
jsonobj_new.project.path_with_namespace = user_name_hold_url[3].concat("/").concat(repo1);
jsonobj_new.project.namespace = name1;
jsonobj_new.project.http_url = entire_url_from_config;


for(i=0;i<1;i++){
jsonobj_new.commits[i].author.email = name1;
jsonobj_new.commits[i].id = x;
}
jsonobj_new.repository.name = repo1;
jsonobj_new.repository.git_http_url = 'BOT';

   


console.log(pythonservice1);
console.log(jsonobj_new);
   
   

var urlpython = pythonservice1+"/setup";
console.log("hit pytoh url :: "+urlpython);
var headers = {
    'Content-Type': 'application/json'
};





var dataString = JSON.stringify(jsonobj_new);

var options = {
    url: urlpython,
    method: 'POST',
    body: dataString,
	headers: headers
};

function callback(error, response, body) {
    if (!error) {
	//result ='true';        
	console.log(body);
	console.log(response.statusCode);
	if(JSON.stringify(response.statusCode) == '200')
	{
		console.log("Checking inside 200 code");
			result = "Build Started with ID :: ";
			result = result.concat(check);
			console.log(result);
			
				cmd_to_delete_tmp = 'cd /tmp && rm -rf '+repo1+' && dir';
	exec(cmd_to_delete_tmp, function(error, stdout, stderr) {
  
  console.log(stdout);
});
	//return result;
	console.log();
	callback_for_token_coffee(null,check,null);
	}
    }
	else
	{
		callback_for_token_coffee(error,"Status code is not 200",null);
		console.log(error);
	}
	
}

request(options, callback);






//return result;


});

  
  
  
  
  
  //var reply = function_check();
/*    console.log("**************************************************"+reply);
  if(result == 'true')
  {
		console.log("Going inside checking reply after statuscode");
	  var str = 'Build is Successful'.concat(check);
	  console.log(str);
	  return str;
  }*/
  //setTimeout(function_check, 5000);//	WAIT HAS TO BE THERE BEACUSE IT TAKES 5 SECONDS TO DOWNLOAD
}

function function_check() {
	

}


module.exports = {
  callname: function_call	// MAIN FUNCTION
  
}