var request = require('request');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (urelease_url, username, password, callback_create_release) {
var headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
};

var fs = require('fs')
var dataString = fs.readFileSync('create_release.json', 'utf8');

var options = {
    url: urelease_url + '/releases/',
    method: 'POST',
    headers: headers,
    body: dataString,
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
console.log(error);
    if (!error && response.statusCode == 200) {
        
		var str = 'Release created';
		callback_create_release("null",str,"null");
    }
	else
	{
		callback_create_release("Error","Error","Error");
	}
}

request(options, callback);
}




module.exports = {
  create_release: function_call	// MAIN FUNCTION
  
}