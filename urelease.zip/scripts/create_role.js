process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var Base64 = require('js-base64').Base64;
var request = require("request");
var function_call = function (urelease_url, username, password, role_name, callback_create_role) {
var user_pass = username + ':' + password;
var buf = Base64.encode(user_pass);
console.log(buf);
var options = { method: 'POST',
  url: urelease_url + '/roles/',
  headers:
   { 'content-type': 'application/json',
     authorization: 'Basic '+buf,
     accept: 'application/json' },
  body:
{
  "name": role_name,
  "description": role_name,
  "actions": [
      ""
  ]
},
  json: true };

request(options, function (error, response, body) {

  if (error){
	  
	  callback_create_role("Error","Error","Error");
  }
  else if(response.statusCode == 200){
	console.log(body);
body = JSON.parse(body);
var str = 'Role created with ID : '+body.id+' name : '+body.name+' version : '+body.version;

callback_create_role("null",str,"null");
	
  }

  
});


}




module.exports = {
  create_role: function_call	// MAIN FUNCTION
  
}