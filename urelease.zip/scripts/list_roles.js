process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var request = require('request');
var function_call = function (urelease_url, username, password, callback_list_roles) {

var options = {
    url: urelease_url + '/roles/actions',
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
body = JSON.parse(body);
var len = body.length;
var str = '*ID*\t\t\t*NAME*\t\t\t*RESOURCE*';
for(i=0;i<len;i++)
{
str = str + body[i].id+' \t\t '+body[i].name+' \t\t '+body[i].resourceType + '\n';
}
callback_list_roles("null",str,"null");


    }
	else
	{
		callback_list_roles("Error","Error","Error");
	}
}

request(options, callback);
}




module.exports = {
  list_roles: function_call	// MAIN FUNCTION
  
}