process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var Base64 = require('js-base64').Base64;
var request = require("request");

var function_call = function (urelease_url, username, password, app_name, callback_create_app) {
var user_pass = username + ':' + password;
var buf = Base64.encode(user_pass);
console.log(buf);
var options = { method: 'POST',
  url: urelease_url + '/applications/',
  headers:
   { 'content-type': 'application/json',
     authorization: 'Basic '+buf,
     accept: 'application/json' },
  body:
   { name: app_name,
     description: 'Creating application from bot with user '+ username,
     teams: [ '00000000-0000-0000-0000-000000000206' ],
     releaseEnvironments:
      [ '00000000-0000-0000-0000-000000000016',
        '00000000-0000-0000-0000-000000000017',
        '00000000-0000-0000-0000-000000000018',
        '00000000-0000-0000-0000-000000000019',
        '00000000-0000-0000-0000-000000000020' ] },
  json: true };

request(options, function (error, response, body) {
  if (error){
	  callback_create_app("Error","Error","Error");
  }
  else{
	  
	  
	  
	  //body = JSON.parse(body);
	  var str = 'Application created with ID :: '+body.id+' and Name :: '+body.name;
	  callback_create_app("null",str,"null");
  }

  console.log(body);
});
}




module.exports = {
  create_app: function_call	// MAIN FUNCTION
  
}