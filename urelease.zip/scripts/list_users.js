var request = require("request");
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

var function_call = function (urelease_url, username, password, callback_list_users) {
var options = { method: 'GET',
  url: urelease_url + '/users/name',
  qs: { json: '', username: username, password: password },
  headers:
   {

     'content-type': 'application/json',
      } };

request(options, function (error, response, body) {
  if (error){
	callback_list_users("Error","Error","Error");
  }
  else
  {
                        body = JSON.parse(body);
                        var length = body.length;
                        var str = '*ID*\t\t\t*NAME*\t\t\t*ActualName*\t\t\t*Email*\t\t\t*DisplayName*';
                        console.log(length);
                        for(i=0;i<length;i++)
                        {
                                str = str + body[i].id+' \t\t '+body[i].name+' \t\t '+body[i].actualName+' \t\t '+body[i].email+' \t\t '+body[0].displayName + '\n';
                        }
						
						callback_list_users("null",str,"null");

  }
});
}




module.exports = {
  list_users: function_call	// MAIN FUNCTION
  
}