//CREATE USER
var fs = require('fs')

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

var function_call = function (urelease_url, username, password, callback_create_user) {
var dataString = fs.readFileSync('./create_user.json', 'utf8');
var request = require('request');

var headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
};



var options = {
    url: urelease_url + '/users/',
    method: 'POST',
    headers: headers,
    body: dataString,
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 201) {
        console.log(body);
        console.log(response.statusCode);
		var str = 'User created';
		callback_create_user("null",str,"null");
    }
	else
	{
		callback_create_user(body,"Error","Error");
	}
}

request(options, callback);

}




module.exports = {
  create_user: function_call	// MAIN FUNCTION
  
}