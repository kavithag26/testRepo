var request = require('request');

var headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
};

var username = 'admin';
var password = 'admin';
var url = 'https://10.224.86.165:8443';
var fs = require('fs')
var dataString = JSON.parse(fs.readFileSync('./scripts/create_release.json', 'utf8'));

var options = {
    url: url + '/releases/',
    method: 'POST',
    headers: headers,
    body: dataString,
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
}

request(options, callback);
