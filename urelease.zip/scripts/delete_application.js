var request = require('request');


process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var request = require("request");

var function_call = function (urelease_url, username, password, app_name, callback_delete_application) {


var options = { method: 'GET',
  url: urelease_url + '/applications/?json&username='+username+'&password='+password+'&name='+app_name,
  headers:
   {
     accept: 'application/json' } };

request(options, function (error, response, body) {

body = JSON.parse(body);
var id = body[0].id;
console.log(id);




var options_del = {
    url: urelease_url + '/applications/'+id,
    method: 'DELETE',
    auth: {
        'user': username,
        'pass': password
    }
};

function callback_del(error, response, body) {
    if (!error && response.statusCode == 200) {
		var str = 'Application deleted with ID : '+id;
		callback_delete_application("null",str,"null");
        console.log(body);
    }
	else
	{
		callback_delete_application("Error","Error","Error");
	}
}

request(options_del, callback_del);


});

}


module.exports = {
  delete_application: function_call	// MAIN FUNCTION
  
}