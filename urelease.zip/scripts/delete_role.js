process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var request = require('request');
var function_call = function (urelease_url, username, password, role_name, callback_delete_role) {

var options = {
    url: urelease_url + '/roles/name',
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
body = JSON.parse(body);
var len = body.length;
var flag = 11;
for(i=0;i<len;i++)
{


if(body[i].name == role_name){

																							var id = body[i].id;
																							var options_del = {
																								url: urelease_url + '/roles/'+id,
																								method: 'DELETE',
																								auth: {
																									'user': username,
																									'pass': password
																								}
																							};
																							function callback_del(error, response, body) {
																								if (!error) {
																									console.log(body);	
																									callback_delete_role("null","Role deleted","null");
																								}
																								else
																								{
																									callback_delete_role("Error in deleting role","Error","Error");
																								}
																							}

																							request(options_del, callback_del);
																							





	flag = 0;
		break;

}
else
{
	//callback_delete_role("Error in deleting role","Error","Error");
	flag = -1;
}



    }
if(flag == -1)
{
	callback_delete_role("Error in deleting role","Error","Error");
}
	

}


}
request(options, callback);
}


module.exports = {
  delete_role: function_call	// MAIN FUNCTION
  
}