//DELETE USER
var request = require('request');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (urelease_url, username, password, user_name, callback_delete_user) {
var user_name = user_name;
var options = {
    url: urelease_url + '/users/name',
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        //console.log(body);
body = JSON.parse(body);

        var len = body.length;
for(i=0;i<len;i++)
{
        console.log(body[i].id + ' -- '+ body[i].name);
        if(body[i].name == user_name)
        {
                console.log(body[i].id)
				
				
				
				var options_delete = {
    url: urelease_url + '/users/'+body[i].id,
    method: 'DELETE',
    auth: {
        'user': username,
        'pass': password
    }
};

function callback_delete(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
		var str = 'User deleted with name : '+user_name;
		callback_delete_user("null",str,"null");
    }
	else
	{
		callback_delete_user("Error","Error","Error");
	}
}

request(options_delete, callback_delete);
				
			

        }
}
    }
}

request(options, callback);

}




module.exports = {
  delete_user: function_call	// MAIN FUNCTION
  
}