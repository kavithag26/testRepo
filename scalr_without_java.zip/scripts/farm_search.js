var HashMap = require('hashmap');
var request = require("request");	
var querystring = require('querystring');
	var CryptoJS = require("crypto-js");
	process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

   var function_call = function (main_scalr_url, access_id, access_key, envid, farm_name, callback_farm_search) {

	
    var path = '/api/v1beta0/user/' + envid + '/farms/'+farm_name;
	var access_id = access_id;
	var access_key = access_key;




var params = '';
    
    var queryString, headers;
    var timestamp = new Date().toISOString();
	var date = timestamp;
	
    var scalrAddress = main_scalr_url;
makeQueryString = function(params) {
    if (params.length == 0) {
      return '';
    }
    if (JSON.stringify(params) === '{}') {
      return '';
    }
    var sorted = [];
    for(var key in params) {
      sorted[sorted.length] = key;
    }
    sorted.sort();
    var result = encodeURIComponent(sorted[0]) + '=' + encodeURIComponent(params[sorted[0]]);
    for (var i = 1; i < sorted.length; i ++) {
      result += '&' + encodeURIComponent(sorted[i]) + '=' + encodeURIComponent(params[sorted[1]]);
    }
    return result;
  }
    if (!params) {
      queryString = '';
    } else if (typeof params === 'string') {
      queryString = params; 
    } else {
      queryString = this.makeQueryString(params);
    }

    if (scalrAddress.endsWith('/')) {
      scalrAddress = scalrAddress.substring(0, scalrAddress.length - 1);
    }

    
	
	




    
var toSign = 'GET' + '\n' + date + '\n' + path + '\n' + '' + '\n';
    var signature = CryptoJS.enc.Base64.stringify(CryptoJS.HmacSHA256(toSign, access_key));

var sign = "V1-HMAC-SHA256 "+signature;

	
	
	
	var headers = {'X-Scalr-Key-Id': access_id,
                   'X-Scalr-Date' : date,
                   'X-Scalr-Debug' : '1',
				   'X-Scalr-Signature' : sign
				   };

	
	
	
	var url_final = scalrAddress + path + (queryString.length > 0 ? '?' + queryString : '');

	
	
	  	var options = { method: 'GET',
	url: url_final,
	headers: headers
	};
	
	request(options, function (error, response, body) {
		
		body = JSON.parse(body);
		//console.log(body);
		
		var final_str = '';
		
		
			
			final_str = "\nName: " + body.data.name +"\nID: "+ body.data.id +"\nStatus: "+ body.data.status +"\nProject-ID: "+ body.data.project.id +"\nEmailID: "+ body.data.owner.email;
			//console.log(final_str);
		
		

			if (error)
			{
				callback_farm_search("Something went wrong","Something went wrong","Something went wrong");
				
		}		
			else{
				
			callback_farm_search(null,final_str,null);
			
			}
			
	
  

});


}






module.exports = {
 farm_search: function_call	// MAIN FUNCTION
  
}