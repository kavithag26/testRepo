var request = require("request");
var CryptoJS = require("crypto-js");
var HashMap = require('hashmap');

var function_call = function (main_scalr_url, access_id, access_key, envid, farm_id, callback_farm_resume) {
var farm_name = farm_name;
var envid= envid;

var path = '/api/v1beta0/user/'+envid+'/farms/'+farm_id+'/actions/resume/';
var scalr_url = main_scalr_url + path;
var secret_key = access_key;
var access_id = access_id;

	    var timestamp = new Date().toISOString();
	var date = timestamp;


	
	var method = 'POST';
var params = '';


var toSign = method + '\n' + date + '\n' + path + '\n' + params + '\n';

//console.log(toSign);
var signature1 = CryptoJS.enc.Base64.stringify(CryptoJS.HmacSHA256(toSign, secret_key));
var sign = "V1-HMAC-SHA256 "+signature1;

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var options = { method: 'POST',
  url: scalr_url,
  headers: 
   { 
     'content-type': 'application/json',
     'x-scalr-signature': sign,
     'x-scalr-key-id': access_id,
     'x-scalr-date': date },
  json: true };

request(options, function (error, response, body) {
	//console.log(response.statusCode);
	
  if (error){
	  callback_farm_resume("Something went wrong","Something went wrong","Something went wrong");
  }
  else if(response.statusCode == 409)
  {
	  callback_farm_resume("Conflict with current state","Conflict with current state","Conflict with current state");
  }
  else
  {
	  //console.log(response.body.data.id);
	  callback_farm_resume(null,"",null);
	  //console.log(body);
  }
	
  
});


}

module.exports = {
 farm_resume: function_call	// MAIN FUNCTION
  
}