var request = require("request");
var function_call = function (resource_name, udeploy_url, username, password, callback_delete_resource) {




var udeploy_url = udeploy_url;
var username = username;
var password = password;
var resource_name = resource_name;

var url = udeploy_url + '/cli/resource';
var options = { method: 'GET',
  url: url,
  auth: {
    user: username,
    password: password
  },
  qs: { active: 'true' }
 };
var active_components = '';
request(options, function (error, response, body) {
  if(error || response.statusCode != 204)
  {
          console.log("Error in deleting resource: "+error);
		  callback_delete_resource("Failed to delete the resource. Check bot logs for error stacktrace","Error","Error");
  }
  else
  {        body = JSON.parse(body);
          var length = body.length;
          for(i=0;i<length;i++)
          {
                                if(resource_name == body[i].name)
                                {
                                        var url = udeploy_url + '/cli/resource/deleteResource?resource='+body[i].id;
                                        var options_delete = {
                                                                url: url,
                                                                method: 'DELETE',
                                                                auth: {
                                                                        'user': username,
                                                                        'pass': password
                                                                                }
                                                                };

                                        function callback_delete(error, response, body) {
                                                if (!error && response.statusCode == 200) {
                                                                console.log(body);
																var str = 'Resource deleted with name :: '+resource_name;
																callback_delete_resource("null",str,"null");
                                                        }
														else
														{
															console.log("Error in deleting resource: "+error);
															callback_delete_resource(error,"Error","Error");
														}
                                                        }

                                                        request(options_delete, callback_delete);
                                                        break;
                                }
          }
  }

});



}




module.exports = {
  delete_resource: function_call	// MAIN FUNCTION
  
}