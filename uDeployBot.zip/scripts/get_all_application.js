var request = require("request");
var function_call = function (udeploy_url, username, password, callback_list_application) {

var request = require("request");
var udeploy_url = udeploy_url;
var username = username;
var password = password;

var url = udeploy_url + '/cli/application';
var options = { method: 'GET',
  url: url,
  auth: {
    user: username,
    password: password
  },
  qs: { active: 'true' }
 };
var active_components = '*ID*\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t*SecurityID*\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t*EpochTime*\t\t\t\t\t\t*UserName*\t\t\t*Application Name*';
request(options, function (error, response, body) {
  if(error || response.statusCode != 200)
  {
          console.log("Error in getting applications: "+error);
		  callback_list_application("Failed to fetch data. Check bot logs for error stacktrace","Error","Error");
  }
  else
  {

          body = JSON.parse(body);
          var length = body.length;

          for(i=0;i<length;i++)
          {
                  active_components = active_components + '\n' + body[i].id + '\t' + body[i].securityResourceId + '\t' + body[i].created + '\t\t' + body[i].user + '\t\t' + body[i].name;
          }
		  callback_list_application("null",active_components,"null");
  }
        console.log(active_components);

});


}




module.exports = {
  get_all_application: function_call	// MAIN FUNCTION
  
}