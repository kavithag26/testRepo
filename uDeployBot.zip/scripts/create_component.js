var request = require("request");
var function_call = function (component_name, udeploy_url, username, password, callback_create_component) {



var udeploy_url = udeploy_url;
var username = username;
var password = password;
var component_name = component_name;
var dataString = '{"name":"'+component_name+'"}';
var url = udeploy_url + '/cli/component/create';
var options = {
    url: url,
    method: 'PUT',
    body: dataString,
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
		body = JSON.parse(body);
		var id = 'Component created with ID :: '+body.id;
        console.log(body.id);
		callback_create_component("null",id,"null");
    }
	else
	{
		console.log("Error in creating component: "+error);
		callback_create_component("Failed to create component. Check bot logs for error stacktrace","Error","Error");
	}
}

request(options, callback);



}




module.exports = {
  create_component: function_call	// MAIN FUNCTION
  
}