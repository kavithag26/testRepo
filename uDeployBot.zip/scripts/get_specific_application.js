var request = require("request");
var function_call = function (app_name, udeploy_url, username, password, callback_get_application) {



var udeploy_url = udeploy_url;
var username = username;
var password = password;
var app_name = app_name;
var url = udeploy_url + '/cli/application/info?application=' + app_name;
var options = { method: 'GET',
  url: url,
  auth: {
    user: username,
    password: password
  },
  qs: { active: 'true' }
 };
var active_components = '';
request(options, function (error, response, body) {
  if(error || response.statusCode != 200)
  {
          console.log("Error in getting application details: "+error);
		  callback_get_application("Failed to fetch application data. Check bot logs for error stacktrace","Error","Error");
  }
  else
  {

          body = JSON.parse(body);


                  active_components = active_components + '\nID : ' + body.id + '\tName : ' + body.name + '\tDescription : ' +body.description + '\tEpochTime : ' + body.created + '\tSecurityID : ' + body.securityResourceId + '\tUser : ' +body.user + '\tComponentCount' + body.componentCount;
				  callback_get_application("null",active_components,"null");
  }
        console.log(active_components);

});


}




module.exports = {
  get_specific_application: function_call	// MAIN FUNCTION
  
}