var request = require("request");
var function_call = function (component_name, udeploy_url, username, password, callback_get_component) {


var udeploy_url = udeploy_url;
var username = username;
var password = password;
var component_name = component_name;
var url = udeploy_url + '/cli/component/info?component=' + component_name;
var options = { method: 'GET',
  url: url,
  auth: {
    user: username,
    password: password
  },
  qs: { active: 'true' }
 };
var active_components = '';
request(options, function (error, response, body) {
  if(error || response.statusCode != 200)
  {
          console.log("Error in getting component details: "+error);
		  callback_get_component("Failed to fetch component. Check bot logs for error stacktrace","Error","Error");
  }
  else
  {

         body = JSON.parse(body);

active_components = active_components + '\nID : ' + body.id + '\nName : ' + body.name + '\nEpochTime : ' + body.created + '\nComponentType : ' + body.componentType + '\nUserName : ' + body.user + '\nSecurityID : ' + body.securityResourceId;
 callback_get_component("null",active_components,"null");
  }
        console.log(active_components);

});


}




module.exports = {
  get_specific_component: function_call	// MAIN FUNCTION
  
}