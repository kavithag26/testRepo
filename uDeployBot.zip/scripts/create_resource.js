var request = require("request");
var function_call = function (resource_name, udeploy_url, username, password, callback_create_resource) {



var request = require('request');
var udeploy_url = udeploy_url;
var username = username;
var password = password;
var resource_name = resource_name;
var dataString = '{"name":"'+resource_name+'","description":"creating resource from bot"}';
var url = udeploy_url + '/cli/resource/create';
var options = {
    url: url,
    method: 'PUT',
        body: dataString,
    auth: {
        'user': username,
        'pass': password
    }
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
		body = JSON.parse(body);
        var id = 'Resource create dwith ID : '+body.id;
        console.log(id);
		callback_create_resource("null",id,"null");
    }
	else
	{
		console.log("Error in creating resource: "+error);
		callback_create_resource(error,"Error","Error");
	}
}

request(options, callback);


}




module.exports = {
  create_resource: function_call	// MAIN FUNCTION
  
}