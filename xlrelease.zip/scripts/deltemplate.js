var request=require('request');
var fs=require('fs');
var templatedel= function (url, username, password, id) {



var xlrelease_url = url+"/api/v1/templates/Applications/"+id
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'delete',
  url: xldeploy_url,
 
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==204){
	  console.log("deleted tempalte")
	  callback(null,"deleted tempalte",null);
  }
  });

  
};

module.exports = {
  templatedel: templatedel	// MAIN FUNCTION
  
}

//template("http://10.224.86.160:5516","admin","Devops123","template.json")