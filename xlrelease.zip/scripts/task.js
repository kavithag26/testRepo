var request=require('request');
var fs=require('fs');
var task= function (url, username, password, filename,releaseid,callback) {


var file='./'+filename;


fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
var xlrelease_url = url+"/api/v1/tasks/Applications/"+releaseid+"/tasks"
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:data
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log("created task")
	  callback(null,"created task",null);
  }
  });
  
  });
  
};
module.exports = {
  task: task	// MAIN FUNCTION
  
}
//task("http://10.224.86.160:5516","admin","Devops123","task.json","Release426800536/Phase935321008")