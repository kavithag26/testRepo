var request=require('request');
var fs=require('fs');
var parser = require('xml2json');
var titleget= function (url, username, password, name,callback) {



var xlrelease_url = url+"/api/v1/releases/byTitle?releaseTitle="+name
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: xlrelease_url,
 
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log(body)
	  var json = JSON.parse(parser.toJson(body));
	  console.log(json)
	  callback(null,json,null);
  }
  });

  
};

module.exports = {
  titleget: titleget	// MAIN FUNCTION
  
}

//gettemplate("http://10.224.86.160:5516","admin","Devops@123","mytemplate")