var request=require('request');
var fs=require('fs');
var release= function (url, username, password, filename,releaseid,callback) {


var file='./'+filename;


fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
var xlrelease_url = url+"/api/v1/templates/Applications/"+releaseid+"/create"
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:data
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200)
  {
	  console.log("created release")
	  callback(null,"created release",null);
  }
  });
  
  });
  
};
module.exports = {
  release: release	// MAIN FUNCTION
  
}

//release("http://10.224.86.160:5516","admin","Devops123","release.json","Release426800536")