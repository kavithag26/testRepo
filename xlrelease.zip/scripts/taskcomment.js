var request=require('request');
var fs=require('fs');
var taskcomment= function (url, username, password, taskid, comment, callback) {


var xlrelease_url = url+"/api/v1/tasks/Applications/"+taskid+"/"+comment
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:{"comment" : comment}
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log("task comment added")
	  callback(null,"task comment added",null);
  }
  });
  

  

}
module.exports = {
  taskcomment: taskcomment	// MAIN FUNCTION
  
}
//taskcomment("http://10.224.86.160:5516","admin","Devops123", "comment from bot", "Release426800536/Phase935321008/Task704235464")