var request=require('request');
var fs=require('fs');
var delphase= function (url, username, password, releaseid) {



var xlrelease_url = url+"/api/v1/phases/Applications/"+releaseid
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  //callback(null,null,body);
	  
	  
  }
  else{
	  console.log("deleted phase")
	  //callback(null,"deleted phase",null);
  }
  });
  

  
};

//sphase("http://10.224.86.160:5516","admin","Devops123","phase.json","Release426800536")