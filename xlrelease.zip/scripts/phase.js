var request=require('request');
var fs=require('fs');
var phase= function (url, username, password, filename,releaseid,callback) {


var file='./'+filename;


fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
var xlrelease_url = url+"/api/v1/phases/Applications/"+releaseid+"/phase"
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:data
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200)
  {
	  console.log("created phase")
	  callback(null,"created phase",null);
  }
  });
  
  });
  
};

module.exports = {
  phase: phase	// MAIN FUNCTION
  
}

//phase("http://10.224.86.160:5516","admin","Devops123","phase.json","Release426800536")