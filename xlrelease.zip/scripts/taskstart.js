var request=require('request');
var fs=require('fs');
var taskstart= function (url, username, password, filename, taskid, callback) {


var file='./'+filename;
fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }


var xlrelease_url = url+"/api/v1/tasks/Applications/"+taskid+"/"+start
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:data
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log("task started")
	  callback(null,"task Started",null);
  }
  });
  

  
});
};

module.exports = {
  taskstart: taskstart	// MAIN FUNCTION
  
}
//taskstart("http://10.224.86.160:5516","admin","Devops123", "taskstart.json", "Release426800536/Phase935321008/Task704235464")