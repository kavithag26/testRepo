var request=require('request');
var fs=require('fs');
var releasedel= function (url, username, password, releaseid ,callback) {






var xlrelease_url = url+"/api/v1/releases/Applications/"+releaseid
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:''
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=204)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==204){
	  console.log("deleted release ")
	  callback(null,"deleted release ",null);
  }
  });
  

  
};


module.exports = {
  releasedel: releasedel	// MAIN FUNCTION
  
}

//releasestart("http://10.224.86.160:5516","admin","Devops123","Release426800536")