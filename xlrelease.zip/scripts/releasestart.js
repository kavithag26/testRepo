var request=require('request');
var fs=require('fs');
var releasestart= function (url, username, password, releaseid, callback) {






var xlrelease_url = url+"/api/v1/releases/Applications/"+releaseid+"/start"
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:''
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log("release started")
	  callback(null,"release Started",null);
  }
  });
  

  
};
module.exports = {
  releasestart: releasestart	// MAIN FUNCTION
  
}
//releasestart("http://10.224.86.160:5516","admin","Devops123","Release426800536")