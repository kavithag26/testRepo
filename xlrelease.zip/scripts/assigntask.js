var request=require('request');
var fs=require('fs');
var assigntask= function (url, username, password, taskid, username,callback) {






var xlrelease_url = url+"/api/v1/tasks/Applications/"+taskid+"/"+username
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: xldeploy_url,
  headers: 
   {'Content-Type':'application/json'},
  body:''
  };
  
  request(options, function (error, response, body) {
	
	
	
		
  if (error)
  {
	  callback(error,null,null);
  }
  if (response.statusCode!=200)
  {
	  console.log(body)
	  callback(null,null,body);
	  
	  
  }
  if (response.statusCode==200){
	  console.log("task assigned")
	  callback(null,"task assigned",null);
  }
  });
  

  
};
module.exports = {
  assigntask: assigntask	// MAIN FUNCTION
  
}
//assigntask("http://10.224.86.160:5516","admin","Devops123","Release426800536/Phase935321008/Task704235464","admin")