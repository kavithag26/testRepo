var neo4j = require('neo4j');
var request = require("request");

var db = new neo4j.GraphDatabase('http://neo4j:C0gnizant@1@10.155.143.184:7474');
db.cypher({
    query: 'MATCH p=()-[r:LOADRUNNER_TRG_BY_JENKINS]->() RETURN p LIMIT 1',
}, function (err, results) {
	if(!err)
	{
		
		
		
		var first_table_data = '';	
		//console.log(results[0].p.start);
		var options = { method: 'GET',
  url: results[0].p.start,
      auth: {
        'user': 'neo4j',
        'pass': 'C0gnizant@1'
    }
  };

request(options, function (error, response, body) {
  if (error) throw new Error(error);
body=JSON.parse(body);

  first_table_data = body.data;

  		var second_table_data = '';
		//console.log(results[0].p.end);
		var options_1 = { method: 'GET',
  url: results[0].p.end,
      auth: {
        'user': 'neo4j',
        'pass': 'C0gnizant@1'
    }
  };

request(options_1, function (error, response, body) {
  if (!error){
body=JSON.parse(body);
  
  second_table_data = body.data;

        for (var key in first_table_data) {
       for (var key_1 in second_table_data) {

	   if(first_table_data[key] == second_table_data[key_1])
	   {
		   console.log(first_table_data.toolName+'.'+key+'  ('+first_table_data[key]+')  == '+second_table_data.toolName+'.'+key_1+'  ('+second_table_data[key_1]+')  ');
	   }
	   else
	   {

	   }
	   }
   }
   
   
}
});  
});
}
});