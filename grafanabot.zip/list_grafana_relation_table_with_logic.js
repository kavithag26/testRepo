
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
//var function_call = function (callback_list_grafana_relation_table_with_logic) {

var neo4j_ip = '10.155.143.184';//((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
//console.log(neo4j_ip);
var db = new neo4j.GraphDatabase('http://neo4j:C0gnizant@1@'+neo4j_ip+':7474');

var relation = '';
db.cypher({
    query: 'MATCH (n)-[r]->() RETURN distinct type(r) as relation',
}, function (err, results) {
	if(!err)
	{
		
		//console.log(results);
		var length = results.length;
		//console.log(length);
		//console.log(results);
		//console.log(length);
		var final_string = '';
		var i = 0;
			for (var key in results)
			{
		//relation = results[key].relation;
				
				console.log(results[key].relation);
			/*****************************************************/	
				
				db.cypher({
    query: 'MATCH p=()-[r:'+results[key].relation+']->() RETURN p LIMIT 1',
}, function (err, results) {
	if(!err)
	{
		
		
		
		
					var first_table_data = '';
					//console.log(results[0].p.start);
					var options = { method: 'GET',
			  url: results[0].p.start,
				  auth: {
					'user': 'neo4j',
					'pass': 'C0gnizant@1'
				}
			  };

request(options, function (error, response, body) {
  if (error) throw new Error(error);
body=JSON.parse(body);

  first_table_data = body.data;

  		var second_table_data = '';
		//console.log(results[0].p.end);
		var options_1 = { method: 'GET',
  url: results[0].p.end,
      auth: {
        'user': 'neo4j',
        'pass': 'C0gnizant@1'
    }
  };

						request(options_1, function (error, response, body) {
						  if (!error){
						body=JSON.parse(body);
						  var final_string = '';
						  second_table_data = body.data;

								for (var key in first_table_data) {
							   for (var key_1 in second_table_data) {

							   if(first_table_data[key] == second_table_data[key_1])
							   {
								   //console.log(relation+'------------->>>');
								   console.log(key+'--Tool: '+first_table_data.toolName+' == '+key_1+'--Tool: '+second_table_data.toolName+' :: '+second_table_data[key_1]);
								   console.log('\n\n');
							   }
							   else
							   {

							   }
							   }
						   }
						   
						   //callback_list_grafana_relation_table_with_logic(null,final_string,null);
						}
						else
						{
							//callback_list_grafana_relation_table_with_logic("Something went wrong","Something went wrong","Something went wrong");
						}
						});  
});
}
});
/*********************************************************/
				
				
				
				
			}
			
		}
		else
	{
		
	}
	
});

/*
}



module.exports = {
 list_grafana_relation_table_with_logic: function_call	// MAIN FUNCTION
  
}



*/