process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (query, callback_execute_query) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");

var neo4j_username = process.env.NEO4J_USERNAME || 'neo4j';
var neo4j_password = process.env.NEO4J_PASSWORD || 'C0gnizant@1';

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');


var query = query.replace("'", "\'");




console.log(query);	//THIS WILL CONVERT THE ' TO \'

													if( (query.toLowerCase()).includes("set") == true || (query.toLowerCase()).includes("create") == true || (query.toLowerCase()).includes("delete") == true)
													{
														console.log('This cannot be executed');
														callback_execute_query("This cannot be executed","This cannot be executed","This cannot be executed");
													}



//var str = 'MATCH (n:CI:DATA) where n.jen_SCMAuthor in [\'mayank.devops\',\'mayank.gangwal\',\'vishal.r.ganjare\'] and n.jen_Result in [\'SUCCESS\'] return n as res';
//var str = 'MATCH (n:RUNDECK:DATA) where n.run_JobName in [\'DemoAppWarDeploy\',\'TestAWS_Job\',\'TestProjectMayank_Job\'] return n.run_Status as status,count(n.run_Status) as count,n.run_JobName as job_name';
var str = query;
var first_str = str;

str = str.split("return");
str = str[1];
if((str.toLowerCase()).includes("n."))
{
	
														console.log('Return specific field in n');
														





													db.cypher({
														query: query,
													}, function (err, results) {
														if(!err)
														{


															var final_string = '';

															for(i=0;i<results.length;i++)
															{
																console.log(i+'----->>');
																//console.log(results[i]);
																final_string = final_string + 'Row no: ' + (i+1) + '\n';
																for (var key in results[i])
																{
																	
																	final_string = final_string + key + ': ' + results[i][key] + '\t';
																}
																final_string = final_string + '\n';
																
															}
															callback_execute_query(null,final_string,null);
															console.log(final_string);

															
														}
													});
													
	
/*Run normally*/
}
else
{
	console.log('Return n');
	if((str.toLowerCase()).includes("as"))
	{
		console.log('It has alias as');
		str = first_str.split("as")[0];
		str = str + ' as result';
		console.log(str);
		
	}
	else
	{
		console.log('It does not has alias as');
		str = first_str + ' as result';
		console.log(str);
	}
		/***********************************/
																					db.cypher({
																				query: str,
																			}, function (err, results) {
																				if(!err)
																				{
																					console.log(results);
																					var final_string = '';
																					var length = results.length;
																					console.log(length);
																					final_string = final_string + 'Total matching number of rows : '+length+' \n\n\n';
																					if(length > 2)
																					{
																						length =2;
																					}
																					else
																					{
																						
																					}
																					for(i=0;i<length;i++)
																					{
																							final_string = final_string + 'Row no: ' + (i+1) + ' -->\n\n';
																							for (var key in results[i].result.properties)
																							{
																								final_string = final_string + key + '----- ' +results[i].result.properties[key] + '\n';
																							}
																						//console.log('\n\n\n');
																						final_string = final_string + '\n\n\n';
																					}
																					callback_execute_query(null,final_string,null);
																					console.log(final_string);


																				
																			}
																			else
																			{
																				console.log(err);
																				callback_execute_query("Something went wrong","Something went wrong","Something went wrong");
																			}
																			});
																					
		
		/***********************************/
		

}


//var str = 'SET match abc';
/*var logic = logic.replace("'", "\'");
console.log(logic);*/	//THIS WILL CONVERT THE ' TO \'



/*

if( (str.toLowerCase()).includes("set") == true || (str.toLowerCase()).includes("create") == true || (str.toLowerCase()).includes("delete") == true)
{
	console.log('This cannot be executed');
}
else
{
//MATCH (n:CI:DATA) where n.jen_SCMAuthor in [\'mayank.devops\',\'mayank.gangwal\',\'vishal.r.ganjare\'] and n.jen_Result in [\'SUCCESS\'] return n limit 5
//MATCH (n:CI:DATA) where n.jen_SCMAuthor in [\'mayank.devops\',\'mayank.gangwal\',\'vishal.r.ganjare\'] and n.jen_Result in [\'SUCCESS\'] return n.jen_RundeckJobId as Job,n.jen_ShortDesc as Description limit 5
db.cypher({
    query: 'MATCH (n:CI:DATA) where n.jen_SCMAuthor in [\'mayank.devops\',\'mayank.gangwal\',\'vishal.r.ganjare\'] and n.jen_Result in [\'SUCCESS\'] return n as res limit 5',
}, function (err, results) {
	if(!err)
	{


		console.log(results);
		for(i=0;i<results.length;i++)
		{
			console.log(i+'----->>');
			//console.log(results[i]);
			for (var key in results[i])
			{
				
				console.log(key + ' -- ' + results[i][key]);

			}
		}

		
	}
});
}*/




}



module.exports = {
 execute_query: function_call	// MAIN FUNCTION
  
}