
var function_call = function (dash_name, panel_id, generate_id, callback_download_image) {
    var exec = require('child_process').exec;
	var grafana_api_key = process.env.HUBOT_GRAFANA_API_KEY;
	var url = process.env.HUBOT_GRAFANA_HOST+'/render/dashboard-solo/db/';
    var args = "curl -k -H \"Authorization: Bearer "+grafana_api_key+"\" "+url+""+dash_name+"?panelId="+panel_id+" > ./scripts/"+generate_id+"\"";

    exec(args, function (error, stdout, stderr) {
      console.log('stdout: ' + stdout);
      console.log('stderr: ' + stderr);
      if (error == null) {
        callback_download_image(null,"imagedownloaded",null);
      }
    });
	
	
	}






module.exports = {
 download_image: function_call	// MAIN FUNCTION
  
}