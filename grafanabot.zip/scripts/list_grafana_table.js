
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (callback_list_grafana_table) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var db = new neo4j.GraphDatabase('http://neo4j:C0gnizant@1@'+neo4j_ip+':7474');


db.cypher({
    query: 'CALL db.labels()',
}, function (err, results) {
	if(!err)
	{
		
		//console.log(results);
		var length = results.length;
		//console.log(length);
		var final_string = '\nNo.\tLable-name\n';
		for(i=0;i<length;i++)
		{
			final_string = final_string + (i+1) + '\t' + results[i].label + '\n';
		}
		callback_list_grafana_table(null,final_string,null);
	}
	else
	{
		callback_list_grafana_table("Something went wrong","Something went wrong","Something went wrong");
	}
	
});


}



module.exports = {
 list_grafana_table: function_call	// MAIN FUNCTION
  
}



