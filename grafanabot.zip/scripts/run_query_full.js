
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (query, callback_run_query_full) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");

var neo4j_username = process.env.NEO4J_USERNAME
var neo4j_password = process.env.NEO4J_PASSWORD

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');


//var str = 'MATCH (n:RUNDECK:DATA) where n.run_JobName in [\'DemoAppWarDeploy\',\'TestAWS_Job\',\'TestProjectMayank_Job\'] return n.run_Status as status,count(n.run_Status) as count,n.run_JobName as job_name';
//var str = 'SET match abc';
var query = query.replace("'", "\'");
console.log(query);	//THIS WILL CONVERT THE ' TO \'

if( (query.toLowerCase()).includes("set") == true || (query.toLowerCase()).includes("create") == true || (query.toLowerCase()).includes("delete") == true)
{
	console.log('This cannot be executed');
	callback_run_query_full("This cannot be executed","This cannot be executed","This cannot be executed");
}
else
{

db.cypher({
    query: query,
}, function (err, results) {
	if(!err)
	{


		var final_string = '';
		for(i=0;i<results.length;i++)
		{
			console.log(i+'----->>');
			//console.log(results[i]);
			final_string = final_string + 'Row no: ' + (i+1) + '\n';
			for (var key in results[i])
			{
				
				final_string = final_string + key + ': ' + results[i][key] + '\t';
			}
			final_string = final_string + '\n';
			
		}
		callback_run_query_full(null,final_string,null);

		
	}
});
}


}



module.exports = {
 run_query_full: function_call	// MAIN FUNCTION
  
}



