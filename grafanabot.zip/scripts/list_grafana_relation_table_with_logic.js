
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (relation_name, callback_list_grafana_relation_table_with_logic) {

var neo4j_ip = process.env.NEO4J_IP || ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var neo4j_username = process.env.NEO4J_USERNAME || 'neo4j';
var neo4j_password = process.env.NEO4J_PASSWORD || 'C0gnizant@1';

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');
var neo_user = 'neo4j';
var neo_password = 'C0gnizant@1';

db.cypher({
    query: 'MATCH p=()-[r:'+relation_name+']->() RETURN p LIMIT 1',
}, function (err, results) {
	if(!err)
	{
		
		
		
		var first_table_data = '';	
		//console.log(results[0].p.start);
		var options = { method: 'GET',
  url: results[0].p.start,
      auth: {
        'user': 'neo4j',
        'pass': 'C0gnizant@1'
    }
  };

request(options, function (error, response, body) {
  if (error) throw new Error(error);
body=JSON.parse(body);

  first_table_data = body.data;

  		var second_table_data = '';
		//console.log(results[0].p.end);
		var options_1 = { method: 'GET',
  url: results[0].p.end,
      auth: {
        'user': neo_user,
        'pass': neo_password
    }
  };

request(options_1, function (error, response, body) {
	var final_string = '';
  if (!error){
body=JSON.parse(body);
  
  second_table_data = body.data;
	var count = 0;
        for (var key in first_table_data) {
       for (var key_1 in second_table_data) {

	   if(first_table_data[key] == second_table_data[key_1])
	   {
		   count = count + 1;
		   final_string = final_string +count+'.\t'+ first_table_data.toolName+'.'+key+'  ('+first_table_data[key]+')  == '+second_table_data.toolName+'.'+key_1+'  ('+second_table_data[key_1]+')\n\n';
	   }
	   else
	   {

	   }
	   }
   }
   
   callback_list_grafana_relation_table_with_logic(null,final_string,null);
}
else
{
	callback_list_grafana_relation_table_with_logic("Something went wrong","Something went wrong","Something went wrong");
}



});  
});
}
});


}



module.exports = {
 list_grafana_relation_table_with_logic: function_call	// MAIN FUNCTION
  
}



