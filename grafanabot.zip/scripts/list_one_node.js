
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (table_name, callback_list_one_node) {

var neo4j_ip = process.env.NEO4J_IP || ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var table_name = table_name;
var neo4j_username = process.env.NEO4J_USERNAME
var neo4j_password = process.env.NEO4J_PASSWORD

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');


db.cypher({
    query: 'MATCH (n:'+table_name+') RETURN n as res limit 2',
}, function (err, results) {
	if(!err)
	{
				var final_string = '\nNo.\tKey\tValue\n';
				var i = 0;
						var length = results.length;
			console.log(length);
			for(i=0;i<length;i++)
			{
				var z = 0;
				final_string = final_string + '\n\nNode no : '+(i+1)+'\n\n';
			for (var key in results[i].res.properties)
			{
				z = z +1;
				final_string = final_string + z +'.\t'+key+'\t'+results[i].res.properties[key] + '\n';
			}
			final_string = final_string + '\n';
			}
			callback_list_one_node(null,final_string,null);

		}
		else
	{
		callback_list_one_node("Something went wrong","Something went wrong","Something went wrong");
	}
	
});


}



module.exports = {
 list_one_node: function_call	// MAIN FUNCTION
  
}



