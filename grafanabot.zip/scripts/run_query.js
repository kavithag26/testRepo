
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (table_name, logic, callback_run_query) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var neo4j_username = process.env.NEO4J_USERNAME
var neo4j_password = process.env.NEO4J_PASSWORD

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');


var logic = logic.replace("'", "\'");
console.log(logic);
console.log('MATCH (n:'+table_name+') where '+logic+' return n as res');
db.cypher({
    query: 'MATCH (n:'+table_name+') where '+logic+' return n as res',
}, function (err, results) {
	if(!err)
	{
		console.log(results);
		var final_string = '';
		var length = results.length;
		console.log(length);
		final_string = final_string + 'Total matching number of rows : '+length+' \n\n\n';
		if(length > 2)
		{
			length =2;
		}
		else
		{
			
		}
		for(i=0;i<length;i++)
		{
				final_string = final_string + 'Row no: ' + (i+1) + ' -->\n\n';
				for (var key in results[i].res.properties)
				{
					final_string = final_string + key + '----- ' +results[i].res.properties[key] + '\n';
				}
			//console.log('\n\n\n');
			final_string = final_string + '\n\n\n';
		}
		callback_run_query(null,final_string,null);


	
}
else
{
	//console.log(err);
	callback_run_query("Something went wrong","Something went wrong","Something went wrong");
}
});


}



module.exports = {
 run_query: function_call	// MAIN FUNCTION
  
}



