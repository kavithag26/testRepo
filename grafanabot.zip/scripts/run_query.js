
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (table_name, logic, callback_run_query) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var db = new neo4j.GraphDatabase('http://neo4j:C0gnizant@1@'+neo4j_ip+':7474');


var logic = logic.replace("'", "\'");
console.log(logic);

db.cypher({
    query: 'MATCH (n:'+table_name+') where '+logic+' return n as res',
}, function (err, results) {
	if(!err)
	{
		
		var final_string = '';
		var length = results.length;
		console.log(length);
		final_string = final_string + 'Total matching number of rows : '+length+' \n\n\n';
		for(i=0;i<2;i++)
		{
				for (var key in results[i].res.properties)
				{
					final_string = final_string + key + '----- ' +results[i].res.properties[key] + '\n';
				}
			//console.log('\n\n\n');
			final_string = final_string + '\n\n\n';
		}
		callback_run_query(null,final_string,null);


	
}
else
{
	//console.log(err);
	callback_run_query("Something went wrong","Something went wrong","Something went wrong");
}
});


}



module.exports = {
 run_query: function_call	// MAIN FUNCTION
  
}



