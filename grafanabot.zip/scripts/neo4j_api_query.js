//MATCH (n:JENKINS:DATA) where n.jen_ProjectName in [\'BitBucketiSgihtDemo\',\'DeleteWorkspace\',\'TestJob\'] return n.jen_ProjectName, n.jen_Result,count(n.jen_Result)
//MATCH (n:JENKINS:DATA) RETURN n limit 1
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (query, callback_neo4j_api_query) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var neo4j_username = process.env.NEO4J_USERNAME || 'neo4j';
var neo4j_password = process.env.NEO4J_PASSWORD || 'C0gnizant@1';

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');
var neo4j_url = process.env.NEO4J_URL || 'http://10.155.143.184:7474';

var query = query.replace("'", "\'");
console.log(query);	//THIS WILL CONVERT THE ' TO \'

if( (query.toLowerCase()).includes("set") == true || (query.toLowerCase()).includes("create") == true || (query.toLowerCase()).includes("delete") == true)
{
	console.log('This cannot be executed');
	callback_neo4j_api_query("This cannot be executed","This cannot be executed","This cannot be executed");
}

var options = { method: 'POST',
auth: {
        'user': neo4j_username,
        'pass': neo4j_password
    },
  url: neo4j_url + '/db/data/cypher',
  headers: 
   { 
     
    
     'content-type': 'application/json' },
  body: { query: query },
  json: true };

request(options, function (error, response, body) {
  if (!error && response.statusCode == 200){

  var final_string = '';
  
  if(body.data[0][0].data)
  {
	  var length = body.data.length;
	  
	if(length > 2)
	{
		length =2;
	}
	else
	{
		
	}
	  //console.log(body.data[0][0].data);
	  for(j=0;j<length;j++){
		  final_string = final_string + '\nRow no : '+(j+1)+'\n';
	  																for (var key in body.data[j][0].data)
																{
																	
																	final_string = final_string + key + ' -- ' + body.data[j][0].data[key] + '\n';
																}
																
																
	  
	  
	  }
	  callback_neo4j_api_query(null,final_string,null);
  }
  else
  {
	  
	  for(i=0;i<body.data.length;i++)
	  {
		//console.log(body.data[i]);  
		final_string = final_string + '\nRow no : '+(i+1)+'\n';
					for(j=0;j<body.data[i].length;j++)
				  {
					final_string = final_string + body.data[i][j] + '\t';  
					
				  }
				  
				  final_string = final_string + '********************\n';
		
	  }
	  //console.log(final_string);
	  callback_neo4j_api_query(null,final_string,null);
  }
  //console.log(body.data);
  //console.log(body.data.length);
  }
  else
  {
	  callback_neo4j_api_query("Something went wrong","Something went wrong","Something went wrong"); 
  }
});








}



module.exports = {
 neo4j_api_query: function_call	// MAIN FUNCTION
  
}



