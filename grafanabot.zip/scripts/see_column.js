
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (table_name, callback_see_column) {

var neo4j_ip = process.env.NEO4J_IP || ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var neo4j_username = process.env.NEO4J_USERNAME
var neo4j_password = process.env.NEO4J_PASSWORD

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');



db.cypher({
    query: 'MATCH (n:'+table_name+') return n as res limit 1',
}, function (err, results) {
	if(!err)
	{
		
		
		var length = results.length;
		console.log(length);
		var final_string = '';
		for(i=0;i<length;i++)
		{
			var z = 0;
				for (var key in results[i].res.properties)
				{
					z = z + 1;
					final_string = final_string+ z + '.\t' + key + '\n';
				}
			
		}
		callback_see_column(null,final_string,null);

	
}
else
{
	callback_see_column("Something went wrong","Something went wrong","Something went wrong");
}
});



}



module.exports = {
 see_column: function_call	// MAIN FUNCTION
  
}



