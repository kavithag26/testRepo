
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (callback_list_grafana_relation) {

var neo4j_ip = ((process.env.HUBOT_GRAFANA_HOST.split("//"))[1].split(":"))[0];

var neo4j = require('neo4j');
var request = require("request");
console.log(neo4j_ip);
var neo4j_username = process.env.NEO4J_USERNAME || 'neo4j';
var neo4j_password = process.env.NEO4J_PASSWORD || 'C0gnizant@1';

var db = new neo4j.GraphDatabase('http://'+neo4j_username+':'+neo4j_password+'@'+neo4j_ip+':7474');


db.cypher({
    query: 'MATCH (n)-[r]->() RETURN distinct type(r) as relation',
}, function (err, results) {
	if(!err)
	{
		
		//console.log(results);
		var length = results.length;
		//console.log(length);
		console.log(results);
		console.log(length);
		var final_string = '\nNo.\tRelation-name\n';
		var i = 0;
			for (var key in results)
			{
				i = i+ 1;
				final_string = final_string + (i) + '\t' +results[key].relation + '\n';
				
			}
			callback_list_grafana_relation(null,final_string,null);
		}
		else
	{
		callback_list_grafana_relation("Something went wrong","Something went wrong","Something went wrong");
	}
	
});


}



module.exports = {
 list_grafana_relation: function_call	// MAIN FUNCTION
  
}



