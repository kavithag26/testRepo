var neo4j = require('neo4j');
var request = require("request");

var db = new neo4j.GraphDatabase('http://neo4j:C0gnizant@1@10.155.143.184:7474');
var table_name = 'InSight';


//MATCH (n:InSight) RETURN n as res LIMIT 1
//MATCH (n:InSight) RETURN distinct n.ToolName as res


db.cypher({
    query: 'MATCH (n:InSight) where n.ToolName=\'RUNDECK\' return n as res',
}, function (err, results) {
	if(!err)
	{
		
		
		var length = results.length;
		console.log('Count :: '+length);
		for(i=0;i<2;i++)
		{
			
				for (var key in results[i].res.properties)
				{
					console.log(key+' -------- '+results[i].res.properties[key]);
					
				}
			console.log('\n\n\n********\n\n\n');
		}


	
}
else
{
	console.log(err);
}
});