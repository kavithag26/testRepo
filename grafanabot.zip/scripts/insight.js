var request = require('request');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (callback_insight) {
var headers = {
    'Authorization': 'Bearer '+process.env.HUBOT_GRAFANA_API_KEY
};

var options = {
    url: process.env.HUBOT_GRAFANA_HOST+'/api/search',
    headers: headers
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        //console.log(body);
		body = JSON.parse(body);
		//console.log(body.length);
		var final_string = '';
		for(i=0;i<body.length;i++)
		{
			only_dash_name = body[i].uri.split("/")[1];
			var z = i+1;
			final_string = final_string + z + '. Title :: ' + body[i].title + ' -- ID :: ' + body[i].id + ' -- Name :: ' + only_dash_name +'\n';
		}
		callback_insight(null,final_string,null);
    }
	else
	{
		callback_insight("Something went wrong","Something went wrong","Something went wrong");
	}
}

request(options, callback);
}






module.exports = {
 insight: function_call	// MAIN FUNCTION
  
}



