
var function_call = function (dash_name, panel_id, room_id, callback_upload_image) {
    /*var exec = require('child_process').exec;

    var args = "curl -F file=@sample.png -F channels=D6A4DPY2C -F token=xoxp-214727999139-214931907989-230011596405-4363fa275d4ef00e8cef07ac47beec7d  https://slack.com/api/files.upload";

    exec(args, function (error, stdout, stderr) {
      console.log('stdout: ' + stdout);
      console.log('stderr: ' + stderr);
      if (error == null) {
        callback_upload_image(null,"imageuploaded",null);
      }
    });
	
	
	*/
console.log('**************************************************');
var delete_flag = false;
var request = require('request');
var fs = require('fs');

var slack_api_token = process.env.HUBOT_SLACK_TOKEN;
request.post({
    url: 'https://slack.com/api/files.upload',
    formData: {
        token: slack_api_token,
        title: "Image from "+dash_name+" panel : "+panel_id,
        filename: "image.png",
        filetype: "auto",
        channels: room_id,
        file: fs.createReadStream('./scripts/sample.png'),
    },
}, function (err, response) {
	console.log(err);
	console.log(response.statusCode);
	if(!err && response.statusCode == 200)
	{
		callback_upload_image(null,"imageuploaded",null);
		delete_flag = true;
		var exec = require("child_process").exec
		exec("rm -rf sample.png", (error, stdout, stderr) => {
		console.log('Deleted the image');
		console.log(error);
		})
	}
});
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}






module.exports = {
 upload_image: function_call	// MAIN FUNCTION
  
}