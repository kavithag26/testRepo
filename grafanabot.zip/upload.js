   /* var args = "curl -F file=@sample.png -F channels=D6A4DPY2C -F token=xoxp-214727999139-214931907989-230011596405-4363fa275d4ef00e8cef07ac47beec7d  https://slack.com/api/files.upload";
	var exec = require('child_process').exec;
    exec(args, function (error, stdout, stderr) {
      console.log('stdout: ' + stdout);
      console.log('stderr: ' + stderr);
	  console.log('stderr: ' + error);
    });*/
	
	
	
var request = require('request');
var fs = require('fs');


request.post({
    url: 'https://slack.com/api/files.upload',
    formData: {
        token: 'xoxp-214727999139-214931907989-230011596405-4363fa275d4ef00e8cef07ac47beec7d',
        title: "Image from js",
        filename: "image.png",
        filetype: "auto",
        channels: 'D6A4DPY2C',
        file: fs.createReadStream('./scripts/sample.png'),
    },
}, function (err, response) {
	console.log(err);
    console.log(JSON.parse(response.body));
});