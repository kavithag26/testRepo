var Git = require("../node_modules/nodegit");
var exec = require('child_process').exec;

var request = require('../node_modules/request');

var fs = require('../node_modules/fs');
var name1 = '';
var repo1 ='';
var branch1 = '';
var pythonservice1 = '';






var result = 'false';

var function_call = function (name, repo, branch, pythonservice, clone_link) {

name1 = name;
repo1 = repo;
branch1 = branch;
pythonservice1 = pythonservice;


path_sample = '/tmp';
Git.Clone(clone_link, path_sample)

  .catch(function(err) { console.log(err); });

  wait(5000);
  
  function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}
  
  
  console.log("Downloaded from GitHub");
  
  function_check();
    console.log(result);
  if(result == 'true')
  {
	  return 'Success';
  }
  //setTimeout(function_check, 5000);//	WAIT HAS TO BE THERE BEACUSE IT TAKES 5 SECONDS TO DOWNLOAD
}

function function_check() {
	cmd = 'cd gitclone && dir';
	exec(cmd, function(error, stdout, stderr) {
  
  console.log(stdout);
});

filepath = "/tmp/.git/config";
user_name_hold_url = '';
ref_name_hold_url = '';
fs.readFile(filepath, function (err, data) {
   if (err){
      console.log(err.stack);
      return;
   }
   data = data.toString();
   //console.log(data.toString());
   split_data = data.split("\n");
   for(i=0;i<split_data.length;i++)
   {
	  //console.log(split_data[i].trim());
		split_data_1 = split_data[i].split("=");
		//console.log(split_data_1[0].trim());
		if(split_data_1[0].trim() == 'url')
		{
			console.log(split_data_1[0].trim()+"------------"+split_data_1[1].trim());
			user_name_hold_url = split_data_1[1].trim();
		}
		if(split_data_1[0].trim() == 'merge')
		{
			console.log(split_data_1[0].trim()+"------------"+split_data_1[1].trim());
			ref_name_hold_url = split_data_1[1].trim();
		}
		
   }
   user_name_hold_url = user_name_hold_url.split("/");
   
   console.log("Ref : "+ref_name_hold_url);//ref
   console.log("path with namespcae : "+user_name_hold_url[3].concat("/").concat(repo1));//IT IS ORGANIZATION NAME FROM CONFIG AND REPO
   
   x=(Math.random()*1e62).toString(36);
   console.log("Namespace :: "+name1);
   
   console.log("Email :: "+name1);// NAME COMING FROM ARGUMENTS
   console.log("commit id :: "+x);//commitid
   console.log("name : "+repo1);
   //console.log("Repo : "+repo1);
   
   var jsonobj_new = {

            ref: "a",
            project: 
            {
                path_with_namespace: "a",
                namespace: "a",
            },
			commits: [{
			         author:
					 {
						 email: "a"
					 },
					 id: "a"
			}],
	    repository:
	    {
		name: "a",
		git_http_url: "BOT"
	    }
        

};
jsonobj_new.ref = ref_name_hold_url;
jsonobj_new.project.path_with_namespace = user_name_hold_url[3].concat("/").concat(repo1);
jsonobj_new.project.namespace = name1;


 var authorObj3 = {
	"email" : name1
};
for(i=0;i<1;i++){
jsonobj_new.commits[i].author = authorObj3;
jsonobj_new.commits[i].id = x;
}
jsonobj_new.repository.name = repo1;
jsonobj_new.repository.git_http_url = 'BOT';

   
 
var path = "/tmp/jsoncontent.json";
var writerStream = fs.createWriteStream(path, {overwrite: false});
writerStream.write(JSON.stringify(jsonobj_new));
writerStream.end();



console.log(jsonobj_new);
   
   

var urlpython = pythonservice1+"/setup";

var headers = {
    'Content-Type': 'application/json',
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36'
};

var options = {
    url: urlpython,
    method: 'POST',
    headers: headers
};

function callback(error, response, body) {
    if (!error) {
        console.log(response.statusCode);
		if(response.statusCode == 200)
		{
			result = 'true';
		}
		console.log(body);
    }
	else{
		console.log(error);
}
}
request(options, callback);





















   // SECOND METHOD
   
   

 /*  
   
  var json_obj = {};
   var refObj = {
    "ref" : ref_name_hold_url
		};

json_obj.commits= new Array();
console.log(json_obj);

var projectObj1 = {
    "path_with_namespace" : user_name_hold_url[3].concat("/").concat(repo1),
	"namespace" : name1
		};
var projectObj2 = {
	"project" : projectObj1
};
json_obj.push( projectObj2 );
var authorObj3 = {
	"email" : name1
};
var commitObj4 = {
	"author" : authorObj3,
	"id" : x
};
json_obj.commits.push(commitObj4);




//json_obj.push( main_commitObj4 );

console.log(json_obj);


   var path = "C:\\Users\\Administrator\\Desktop\\buildbot\\xyz1.json"
   var writerStream = fs.createWriteStream(path, {overwrite: false});

   
   
   writerStream.write(JSON.stringify(json_obj));
writerStream.end();
	  */ 
});


}






module.exports = {
  callname: function_call	// MAIN FUNCTION
  
}