var request = require("request");
var update_call = function (jira_repourl, username, password, comment_jira, issue_key, callback_jira_update){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+issue_key;
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'PUT',
  url: jira_repourl,
  headers: 
   { 
   'Content-Type': 'application/json'
   },
  body: {
            update: {
                        comment: [{
                                    add: {
                                            body: comment_jira 
                                         }
                                  }]
                    }
        },
  json: true 
  };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_jira_update("Cannot Post Comment Either Issue Doesnot Exist or Some Error","Cannot Post Comment Either Issue Doesnot Exist or Some Error",null);
  }
  else
  {
	  callback_jira_update(null,"Comment Posted Successfully",null);
  }

  
});

}

module.exports = {
  update_issue: update_call	// MAIN FUNCTION
  
}