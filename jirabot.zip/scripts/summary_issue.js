var request = require("request");
var summary_call = function (jira_repourl, username, password, issue_key, issue_summary, callback_jira_summary){
var jira_repourl = jira_repourl+"/rest/api/2/issue/"+issue_key;
var options = { 
  auth: {
        'user': username,
        'pass': password
    },
  method: 'PUT',
  url: jira_repourl,
  headers: 
   { 
   'Content-Type': 'application/json'
   },
  body: {
          update: {
                    summary: [{
                                set: issue_summary
                             }]
                  }
        },
  json: true 
  };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_jira_summary("Something went wrong","Something went wrong",null);
  }
  else
  {
	  callback_jira_summary(null,"Summary Updated Successfully",null);
  }

  
});

}

module.exports = {
  summary_issue: summary_call	// MAIN FUNCTION
  
}