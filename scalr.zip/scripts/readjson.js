var fs = require('fs')

function readworkflow(callback) {
	console.log("In reading json");
 //var cmd=method;
 var obj = '';
 //console.log(obj);

 obj = JSON.parse(fs.readFileSync('./scripts/workflow.json', 'utf8'));
 //console.log(obj)
 callback(null, obj,null);

}
module.exports = {
  readworkflow_coffee: readworkflow	// MAIN FUNCTION
  
}