var request = require("request");
var exec = require('child_process').exec;
var fs = require("fs");
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

//var scalr_jar=require("./sample3.jar");

var function_call = function (main_scalr_url, api_url, access_id, access_key, envid, signature1, callback_farm_list) {

var scalr_url = main_scalr_url;
var api_url = api_url;
var signature = signature1;
var final_scalr_url = scalr_url + api_url;
var method = 'GET';
var from_coffee_body = '';
var from_coffee_query = '';
var scalr_secret_key = access_key;
var time = null;
var scalr_key_id = access_id;

	 var send_result_coffee = '';
	 var send_error_coffee ='';
var jar_name= 'sample3';


var output_java = '';
var split_string = '';


  
	
	
	output_java = signature;
	//console.log("output :: "+signature);
	split_string = output_java.split(" ");
	//console.log(split_string.length);
	for(i=0;i<split_string.length;i++)
	{
		console.log(i+" "+split_string[i]);
		if(i == 0)
		{
			time = split_string[i];
			time = time.trim();
		}
		else if(i == 1)
		{
			signature = split_string[i];
			signature = signature.trim();
		}
	}
	
	signature = "V1-HMAC-SHA256 " + signature;

	//console.log('outside');


	var options = { method: 'GET',
	url: final_scalr_url,
	headers: 
	{ 
     'Content-Type': 'application/json',
     'x-scalr-signature': signature,
     'x-scalr-key-id': scalr_key_id,
     'x-scalr-date': time } };
	
	request(options, function (some_error, response, body) {
		
		//console.log(body);
		//console.log(some_error);
			if (some_error)
			{
				//console.log(some_error);
				send_result_coffee = "Some error is there";
				send_error_coffee = "Some error is there";
				callback_farm_list("Some error is there","Some error is there","Some error is there");
		}		
			else{
				//console.log(body);
			var my = JSON.stringify(body);
			var json_obj = JSON.parse(body);
			var length_body = json_obj.data.length;
			for(i=0;i<length_body;i++)
				{
					//console.log(json_obj.data[i].name);
					send_result_coffee = send_result_coffee + json_obj.data[i].id +" > "+json_obj.data[i].name + "\n";
					//send_result_coffee.concat(json_obj.data[i].name);
				}
			send_error_coffee = "null";
			//console.log("smething is here");
			callback_farm_list(null,send_result_coffee,null);
			}
			
		
  

});


}






module.exports = {
 scalr_func: function_call	// MAIN FUNCTION
  
}