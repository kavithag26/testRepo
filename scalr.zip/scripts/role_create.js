var request = require("request");
var CryptoJS = require("crypto-js");
var HashMap = require('hashmap');

var function_call = function (main_scalr_url, access_id, access_key, envid, farm_name, role_name, os_name, callback_role_create) {
var farm_name = farm_name;
var envid= envid;
var alias = role_name;
var path = '/api/v1beta0/user/'+envid+'/farms/'+farm_name+'/farm-roles/';
var scalr_url = main_scalr_url + path;
var secret_key = access_key;
var access_id = access_id;

	    var timestamp = new Date().toISOString();
	var date = timestamp;
var os_id = '';
var instance_os_type = '';
if(os_name == 'ubuntu')
{
	os_id = 38241;
	instance_os_type = 't1.micro';
}
else if(os_name == 'windows')
{
	os_id = 59970;
	instance_os_type = 't2.micro';
}
else
{
	os_id = 38241;
	instance_os_type = 't1.micro';
}
	
	var method = 'POST';
var params = '';


var toSign = method + '\n' + date + '\n' + path + '\n' + params + '\n' + '{"alias":"'+alias+'","cloudPlatform":"ec2","cloudLocation":"us-west-2","instanceType":"'+instance_os_type+'","networking":{"networks":[{"id":"vpc-54776630"}],"subnets":[{"id":"subnet-4057c218"}]},"role":'+os_id+',"scaling":{"enabled":false,"maxInstances":1,"minInstances":1},"security":{"securityGroups":[{"id":"sg-bc5efcc5"}]}}';


var signature1 = CryptoJS.enc.Base64.stringify(CryptoJS.HmacSHA256(toSign, secret_key));
var sign = "V1-HMAC-SHA256 "+signature1;

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var options = { method: 'POST',
  url: scalr_url,
  headers: 
   { 
     'content-type': 'application/json',
     'x-scalr-signature': sign,
     'x-scalr-key-id': access_id,
     'x-scalr-date': date },
  body: 
   { alias: alias,
     cloudPlatform: 'ec2',
	 
     cloudLocation: 'us-west-2',
     instanceType: instance_os_type,
	 networking:
	 {
	 networks:
	 [{
		 id: 'vpc-54776630'
	 }],
	 subnets:
	 [{
		 id: 'subnet-4057c218'
	 }]
	 },
     role: os_id,
     scaling:
     {
		 enabled: false,
		 maxInstances: 1,
		 minInstances: 1
	 },
	 security:
	 {
	 securityGroups:
	 [{
		 id: 'sg-bc5efcc5'
	 }]
	 }
	 },
  json: true };

request(options, function (error, response, body) {
  if (error){
	  callback_role_create("Something went wrong","Something went wrong","Something went wrong");
  }
  else if(response.statusCode == 201)
  {
	  //console.log(response.body.data.id);
	  callback_role_create(null,response.body.data.id,null);
	  
  }
  else
  {
	  //console.log(response.body.data.id);
	  callback_role_create("Something went wrong","Something went wrong","Something went wrong");
	  
  }

  
});


}






module.exports = {
 role_create: function_call	// MAIN FUNCTION
  
}