var request = require("request");
fs = require('fs')
function rundeck() {};
rundeck.listproj= function (url, username, password, token, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/projects?format=json"
//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	//console.log(body)
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list="";
	  
	  
	  
	  for(var i=0;i<res.length;i++){
		  list+=res[i].name+"\n";
		  
	  }
	  callback(null,list,null);
  }

  
});






}


rundeck.listjob= function (url, username, password, token, project, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/project/"+project+"/jobs?format=json"
//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list="";
	  
	  
	  if(res.length==0){
		  callback(null,"no jobs yet",null);}
	  else{
		  for(var i=0;i<res.length;i++){
		    list+="JobName: "+res[i].name+" , "+"UUID:"+res[i].id+"\n";
		  
	  }
	  callback(null,list,null);
	  }
  }

  
});






}


rundeck.projconfig= function (url, username, password, token, project, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/project/"+project+"?format=json"
console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	var res=JSON.parse(body);
	
  if (error)
  {
	  console.log(error);
	  callback(error,null,null);
	  
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res.config;
	  console.log(list);
	  
	 callback(null,list,null);
	  
  }

  
});






}


rundeck.runjob= function (url, username, password, token, jobid, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;
//url+"/api/20/job/"+jobid+"/run?format=json"  

var rundeck_url = url+"/api/20/job/"+jobid+"/run?format=json"

//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	//console.log(body);
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res.status+" "+res.id;
	  
	  
	 callback(null,list,null);
	  
  }

  
});






}


rundeck.deleteproj= function (url, username, password, token, project, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/project/"+project+"?format=json"
//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'delete',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	//console.log("del::"+body);
	//console.log("delcode::"+response.statuscode);
	if(body==""){
		callback(null,"deleted",null);
	}
	else{
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res;
	  
	  
	 callback(null,list,null);
	  
  }

  }
  
});






}


rundeck.deletejob= function (url, username, password, token, jobid, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/job/"+jobid+"?format=json"
//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'delete',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	//console.log("del::"+body);
	//console.log("delcode::"+response.statuscode);
	if(body==""){
		callback(null,"deleted job",null);
	}
	else{
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res;
	  
	  
	 callback(null,list,null);
	  
  }

  }
  
});






}


rundeck.exechistory= function (url, username, password, token, project, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;


var rundeck_url = url+"/api/20/project/"+project+"/history?format=json"
console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'delete',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	
	
	
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list="";
	  for(var i=0;i< res.events.length;i++){
		  list+="execution id: "+res.events[i].execution.id+" "+res.events[i].status+"\n";
		  
	  }
	  
	 callback(null,list,null);
	  
  }

  
  
});






}


rundeck.createproject= function (url, username, password, token, filename, callback) {
	
	//?authtoken=E4rNvVRV378knO9dp3d73O0cs1kd0kCd
//var rundeck_url = sonarurl;
//var username = username;
//var password = password;
var file='./'+filename;
console.log(file);
fs.readFile(file, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  console.log(data);
  
  
var rundeck_url = url+"/api/20/projects?format=json"
//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'post',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token ,
	'Content-Type':'application/xml'},
  body:data};

request(options, function (error, response, body) {
	
	
	
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res.name+" created";
	  
	  
	 callback(null,list,null);
	  
  }

  
  
});
});








}

rundeck.checkstatus=function (url, username, password, token, execid, callback) {
	
var rundeck_url = url+"/api/20/execution/"+execid+"?format=json"

//console.log(rundeck_url)
var options = { 
auth: {
        'user': username,
        'pass': password
    },
method: 'get',
  url: rundeck_url,
  headers: 
   {'X-Rundeck-Auth-Token':token  } };

request(options, function (error, response, body) {
	//console.log(body);
	var res=JSON.parse(body);
	
  if (error)
  {
	  callback(error,null,null);
  }
  if (res.error)
  {
	  callback(null,null,res.message);
	  //console.log(res.message);
	  //console.log(body);
  }
  else{
	  var list=res.status+" "+res.id;
	  
	  
	 callback(null,list,null);
	  
  }

  
});



	
}

module.exports = rundeck