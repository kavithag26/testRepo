var request = require("request");
var function_call = function (sonarurl, username, password, projectid, callback_project_delete) {
	
	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var project_id = projectid;

sonar_url = sonar_url+"api/projects/delete?key="+project_id;

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_project_delete("Somwthing went wrong","Somwthing went wrong",null);
  }
  else
  {
	  callback_project_delete(null,"Deleted Successfully",null);
  }

  
});






}




module.exports = {
  delete_project: function_call	// MAIN FUNCTION
  
}