var request = require("request");
var function_call = function (sonarurl, username, password, projectid, callback_project_delete) {
	
	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var project_id = projectid;

sonar_url = sonar_url+"api/projects/delete?key="+project_id;

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
	body = JSON.parse(body);
	
  if (error)
  {
	  callback_project_delete("Something went wrong","Something went wrong","Something went wrong");
  }
  else if(response.statusCode == 204)
  {
	  callback_project_delete(null,"",null);
  }
  else
  {
	  var str = JSON.stringify(body.errors);
	  callback_project_delete(str,str,str);
  }

  
});






}




module.exports = {
  delete_project: function_call	// MAIN FUNCTION
  
}