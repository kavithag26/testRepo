//Load Dependencies
var request = require("request");

//Function to create user with parameters url,username,password,user_id
var function_call = function (sonarurl, username, password, userid, callback_user_create) {	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var user_id = userid;

sonar_url = sonar_url+"api/users/create?login="+user_id+"&password="+user_id+"&name="+user_id;

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
	body = JSON.parse(body);
  if (error)
  {
	  callback_user_create("Something went wrong","Something went wrong",null);
  }
  else if(response.statusCode == 200)
  {
	  callback_user_create(null,"",null);
  }
  else
  {
	  var str = JSON.stringify(body.errors);
	  callback_user_create(str,str,str);
  }

  
});
}
module.exports = {
  create_user: function_call	// MAIN FUNCTION
  
}