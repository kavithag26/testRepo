var request = require("request");
var function_call = function (sonarurl, username, password, perm, projid, userid, callback_grant_user) {
	
	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var user_id = userid;
var permission = perm;
var project_id = projid;

sonar_url = sonar_url+"api/permissions/add_user?permission="+permission+"&login="+user_id+"&projectKey="+project_id;

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
  if (error)
  {
	  callback_grant_user("Somwthing went wrong","Somwthing went wrong",null);
  }
  else if(response.statusCode == 204)
  {
	  callback_grant_user(null,"Granted Successfully",null);
  }
  else
  {
	  callback_grant_user("Somwthing went wrong","Somwthing went wrong",null);
  }

  
});






}




module.exports = {
  grant_user: function_call	// MAIN FUNCTION
  
}