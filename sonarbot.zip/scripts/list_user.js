//Load Dependencies
var request = require("request");

//Function to list user with parameters url,username,password
var function_call = function (sonarurl, username, password, projectid, callback_list_user) {	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var project_id = projectid;

sonar_url = sonar_url+"api/users/search";

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
console.log(body);
console.log(error);
	
  if (error)
  {
	  callback_list_user("Somwthing went wrong","Somwthing went wrong",null);
  }
  else
  {
	  body = JSON.parse(body);
	var length = body.users.length;
	//console.log(length);
	var name = '*No.*\t\t\t*Name*\n';
	//console.log(body.users[0].name);
	for(i=0;i<length;i++)
	{
		var x = i+1;
		name = name + x + "\t\t\t" + body.users[i].name + "\n";
	}
	  callback_list_user(null,name,null);
  }

  
});
}
module.exports = {
  list_user: function_call	// MAIN FUNCTION
  
}