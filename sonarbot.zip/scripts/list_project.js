var request = require("request");
var function_call = function (sonarurl, username, password, projectid, callback_list_project) {
	
	
var sonar_url = sonarurl;
var username1 = username;
var password1 = password;
var project_id = projectid;

sonar_url = sonar_url+"api/projects";

var options = { 
auth: {
        'user': username1,
        'pass': password1
    },
method: 'POST',
  url: sonar_url,
  headers: 
   {  } };

request(options, function (error, response, body) {
	
	console.log(body);
	console.log(error);
  if (error)
  {
	  callback_list_project("Somwthing went wrong","Somwthing went wrong",null);
  }
  else
  {
	  var name = '';
	body = JSON.parse(body);
	var length = body.length;
	for(i=0;i<length;i++)
	{
		var x = i+1;
		name = name+ x + " " + body[i].nm + "\n";
	}
	  callback_list_project(null,name,null);
  }

  
});






}




module.exports = {
  list_project: function_call	// MAIN FUNCTION
  
}