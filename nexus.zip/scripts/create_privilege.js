var request = require("request");
var function_call = function (nexus_repourl, username, password, pri_name, repo_id, callback_create_privilege) {
	
	
	
	
	var nexus_repourl = nexus_repourl+'/service/local/privileges_target';
	var pri_name = pri_name;
	var repo_id = repo_id;
	var username = username;
	var password =password;

	
	
var options = { method: 'POST',
  url: nexus_repourl,
  headers: 
   { 
     'Content-Type': 'application/json',
      },
	 auth: {
        'user': username,
        'pass': password
    },
  body: 
   { data: 
      { name: pri_name,
        description: 'For Testing',
        type: 'target',
        repositoryId: repo_id,
        repositoryTargetId: '1',
        method: [ 'read', 'create', 'update', 'delete'] } },
  json: true };


request(options, function (error, response, body) {
		//console.log(nexus_repourl);
	//console.log(username);
	//console.log(password);
	//console.log(error);
  if (error)
  {
	  callback_create_privilege("Some error is there","Some error is there","Some error is there");
  }
  else
  {
	  callback_create_privilege(null,"Privilege created",null);
  }

  //console.log(body);
});



}




module.exports = {
  create_privilege: function_call	// MAIN FUNCTION
  
}