var request = require("request");
var function_call = function (nexus_url, nexus_user_id, nexus_password, userid, roleid, password1, callback_create_user) {
	//userid = usertocreate && userid(command)
	//roleid = reporole && role(command)
	//nexus_userid(env)
	//url(env)
	//password(env)
	nexus_repourl = nexus_url;
	   random_password=password1;
   
	nexus_repourl = nexus_repourl + "/service/local/users";

	
	
	
	
	var options = {
		    auth: {
        'user': nexus_user_id,
        'pass': nexus_password
    },
	method: 'POST',
  url: nexus_repourl,
  headers: 
   {
     'content-type': 'application/json' },
  body: 
   { data: 
      { email: 'testing@example.com',
        userId: userid,
        status: 'active',
        roles: [ roleid ],
        password: random_password } },
  json: true };
	
	
	
	function callback(error, response, body) {
    if (!error) {

	
	if(JSON.stringify(response.statusCode) == '201')
	{
	

	callback_create_user(null,"",null);
	}
	else
	{
		

	callback_create_user("something went wrong","something went wrong","something went wrong");
	}
    }
	else
	{
		callback_create_user("something went wrong","something went wrong","something went wrong");

	}
	
}

request(options, callback);
	
	
	
	
	
	
	
	}




module.exports = {
  create_user: function_call	// MAIN FUNCTION
  
}