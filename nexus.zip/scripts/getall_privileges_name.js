var function_call = function (nexus_repourl, username, password, name, getall_privileges_name) {





var nexus_repourl = nexus_repourl;
var request = require("request");
var url_link = nexus_repourl+"/service/local/privileges";
var username = username;
var password = password;
var name_search = name;


var options = {
	    auth: {
        'user': username,
        'pass': password
    },
	method: 'GET',
  url: url_link,
  headers: 
   { 
     
     'content-type': 'application/json'
 }
 };

  
  
function callback(error, response, body) {
    if (!error) {

	if(JSON.stringify(response.statusCode) == '200')
	{
	var xmlText = body;
  
	var length_check = xmlText.split("<id>");
	var username = [];
	var status_name = [];
	var role = [];
	var final_answer = '';

	for(i=1; i<length_check.length; i++)
	{
  username[i] = xmlText.split("<id>")[i].split("</id>")[0];
  status_name[i] = xmlText.split("<name>")[i].split("</name>")[0];
  //console.log(status_name[i]);
  //console.log(name_search);
  var check_name_from_coffee = status_name[i].split("-")[0].trim();
  if(name_search == check_name_from_coffee)
  {
	  name_search = username[i] + " " + name_search;
	  //console.log(name_search);
	  
  }
  
  final_answer = final_answer +  "ID :: "+username[i]+"\t Name :: "+status_name[i]+"\n";
		
	}
getall_privileges_name(null,name_search,null);
	
	}
	else
	{
		getall_privileges_name("Something is wrong","Something is wrong",null);
	}
    }
	else
	{
		getall_privileges_name("Something is wrong","Something is wrong",null);
	}
	
}  
  
  
request(options, callback);




}




module.exports = {
  getall_privileges_name: function_call	// MAIN FUNCTION
  
}