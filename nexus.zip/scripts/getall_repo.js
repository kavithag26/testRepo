var function_call = function (nexus_repourl, username, password, callback_getall_repo) {



var Table = require('cli-table');

var nexus_repourl = nexus_repourl;
var request = require("request");
var url_link = nexus_repourl+"/service/local/repositories";
var username = username;
var password = password;



var options = {
	    auth: {
        'user': username,
        'pass': password
    },
	method: 'GET',
  url: url_link,
  headers: 
   { 
     
     'content-type': 'application/json'
 }
 };

  
  
function callback(error, response, body) {
    if (!error) {

	if(JSON.stringify(response.statusCode) == '200')
	{
	var xmlText = body;
  //console.log(xmlText);
	var length_check = xmlText.split("<name>");
	var name = [];
	var url = [];
	var provider = [];
	var id_repo = [];
	var final_answer = "*No.*\t\t\t*ID*\t\t\t*Name*\t\t\t*Provider*\t\t\t*RepoUrl*\n";
	/*var table = new Table({
	head: ['No.', 'ID','Name','Provider','RepoUrl'],
	colWidths: [5,15,10,10,20]
	});*/

	for(i=1; i<length_check.length; i++)
	{
		name[i] = xmlText.split("<name>")[i].split("</name>")[0];
		url[i] = xmlText.split("<contentResourceURI>")[i].split("</contentResourceURI>")[0];
		provider[i] = xmlText.split("<provider>")[i].split("</provider>")[0];
		id_repo[i] = xmlText.split("<id>")[i].split("</id>")[0];
		final_answer = final_answer+i+ "\t\t\t"+id_repo[i]+"\t\t\t"+name[i]+"\t\t\t"+provider[i]+"\t\t\t"+url[i]+"\n";
		//table.push([i,id_repo[i],name[i],provider[i],url[i]]);
	}

	callback_getall_repo(null,final_answer,null);
	}
	else
	{
		callback_getall_repo("not200","Statuscode is not 200",null);
	}
    }
	else
	{
		callback_getall_repo("ServiceDown","Status code is not 200. Service is down.",null);
	}
	
}  
  
  
request(options, callback);




}




module.exports = {
  getall_repo: function_call	// MAIN FUNCTION
  
}